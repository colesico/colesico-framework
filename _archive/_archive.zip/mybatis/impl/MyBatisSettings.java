package colesico.srv.mybatis.impl;

import colesico.srv.mybatis.MyBatisUnit;

import java.util.Map;

/**
 * Created by vvlarion on 30.03.2016.
 */
public class MyBatisSettings {
    private final Map<String,Class<? extends MyBatisUnit>> unitClassesMap;

    public MyBatisSettings(Map<String, Class<? extends MyBatisUnit>> unitClassesMap) {
        this.unitClassesMap = unitClassesMap;
    }

    public Class<? extends MyBatisUnit> getUnitClass(String unitName){
        return unitClassesMap.get(unitName);
    }
}
