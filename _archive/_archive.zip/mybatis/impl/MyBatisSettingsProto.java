package colesico.srv.mybatis.impl;

import java.util.Map;

/**
 * Created by vvlarion on 30.03.2016.
 */
public class MyBatisSettingsProto {

    protected Map<String, String> units;

    public MyBatisSettingsProto() {

    }

    public Map<String, String> getUnits() {
        return units;
    }

    public void setUnits(Map<String, String> units) {
        this.units = units;
    }
}
