package colesico.srv.mybatis.impl;

import colesico.core.config.ConfigKit;
import colesico.core.handler.HandlerKit;
import colesico.core.modlet.ModletKit;
import colesico.core.modlet.exception.ModletNotFoundException;
import colesico.core.module.Module;
import colesico.srv.mybatis.MyBatisKit;
import colesico.srv.mybatis.MyBatisUnit;
import colesico.srv.mybatis.exception.MyBatisException;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.TransactionIsolationLevel;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by vvlarion on 31.03.2016.
 */
@Singleton
public class MyBatisKitImpl implements MyBatisKit {

    protected final ConfigKit configKit;
    protected final ModletKit modletKit;
    protected final Provider<Module> moduleProv;

    protected final ThreadLocal<Map<Class<? extends MyBatisUnit>, SqlSessionHolder>> sessionHolders;

    @Inject
    public MyBatisKitImpl(ConfigKit configKit, HandlerKit handlerKit, ModletKit modletKit, Provider<Module> moduleProv) {
        this.configKit = configKit;
        this.modletKit = modletKit;
        this.moduleProv = moduleProv;
        this.sessionHolders = new ThreadLocal<Map<Class<? extends MyBatisUnit>, SqlSessionHolder>>() {
            @Override
            protected Map<Class<? extends MyBatisUnit>, SqlSessionHolder> initialValue() {
                return new HashMap();
            }
        };
        handlerKit.addThreadLocalControl(sessionHolders);
    }

    protected Class<? extends MyBatisUnit> getUnitClass(String unitName) {
        MyBatisSettings settings = getSettings(configKit, modletKit, moduleProv.get());
        return settings.getUnitClass(unitName);
    }

    protected SqlSessionHolder ensureSessionHolder(Class<? extends MyBatisUnit> unitClass) {
        SqlSessionHolder sessionHolder = sessionHolders.get().get(unitClass);
        if (sessionHolder == null) {
            throw new MyBatisException("Sql sessions does not exist");
        }
        return sessionHolder;
    }

    @Override
    public void open(String unitName, ExecutorType executorType, TransactionIsolationLevel isolation) {
        Class<? extends MyBatisUnit> unitClass = getUnitClass(unitName);
        SqlSessionHolder sessionHolder = sessionHolders.get().get(unitClass);
        if (sessionHolder != null) {
            sessionHolder.incOpenCouter();
            return;
        }

        final MyBatisUnit unit = modletKit.getModlet(unitClass);

        SqlSessionFactory sessionFactory = unit.getSqlSessionFactory();
        if (sessionFactory == null) {
            throw new MyBatisException("MyBatisUnit '" + unitClass.getName() + "' has provided null " + SqlSessionFactory.class.getSimpleName());
        }
        SqlSession sqlSession = sessionFactory.openSession();
        sessionHolder = new SqlSessionHolder(sqlSession);
        sessionHolders.get().put(unitClass, sessionHolder);
    }

    @Override
    public void close(String unitName) {
        Class<? extends MyBatisUnit> unitClass = getUnitClass(unitName);
        SqlSessionHolder sessionHolder = ensureSessionHolder(unitClass);
        if (sessionHolder.decOpenCounter() > 0) {
            return;
        }
        try {
            sessionHolder.getSqlSession().close();
        } finally {
            sessionHolders.get().remove(unitClass);
        }
    }

    @Override
    public void close() {
        close(DEFAULT_UNIT_NAME);
    }


    @Override
    public void commit(String unitName) {
        Class<? extends MyBatisUnit> unitClass = getUnitClass(unitName);
        SqlSessionHolder sessionHolder = ensureSessionHolder(unitClass);
        if (sessionHolder.getOpenCounter() > 1) {
            return;
        }
        if (sessionHolder.getRollback()) {
            throw new MyBatisException("Session marked for rollback");
        }
        sessionHolder.getSqlSession().commit(true);
    }


    @Override
    public void commit() {
        commit(DEFAULT_UNIT_NAME);
    }

    @Override
    public void rollback(String unitName) {
        Class<? extends MyBatisUnit> unitClass = getUnitClass(unitName);
        SqlSessionHolder sessionHolder = ensureSessionHolder(unitClass);
        sessionHolder.setRollback();
        if (sessionHolder.getOpenCounter() > 1) {
            return;
        }
        sessionHolder.getSqlSession().rollback(true);
    }


    @Override
    public void rollback() {
        rollback(DEFAULT_UNIT_NAME);
    }

    @Override
    public <M> M getMapper(String unitName, Class<M> mapperClass) {
        return getSession(unitName).getMapper(mapperClass);
    }

    @Override
    public <M> M getMapper(Class<M> mapperClass) {
        return getMapper(DEFAULT_UNIT_NAME,mapperClass);
    }


    @Override
    public SqlSession getSession(String unitName) {
        Class<? extends MyBatisUnit> unitClass = getUnitClass(unitName);
        SqlSessionHolder sessionHolder = ensureSessionHolder(unitClass);
        return sessionHolder.getSqlSession();
    }


    @Override
    public SqlSession getSession() {
        return getSession(DEFAULT_UNIT_NAME);
    }

    @Override
    public boolean sessionExists(String unitName) {
        Class<? extends MyBatisUnit> unitClass = getUnitClass(unitName);
        return sessionHolders.get().containsKey(unitClass);
    }

    @Override
    public boolean sessionExists() {
        return sessionExists(DEFAULT_UNIT_NAME);
    }


    protected MyBatisSettings getSettings(ConfigKit configKit, ModletKit modletKit, Module module) {
        return configKit.getConfig(module, MyBatisSettings.class, MyBatisSettingsProto.class, (MyBatisSettingsProto proto, Module mod) -> {
            Map<String, String> unitsStr = proto.getUnits();
            Map<String, Class<? extends MyBatisUnit>> unitClassesMap = new HashMap<>();
            for (Map.Entry<String, String> e : unitsStr.entrySet()) {
                try {
                    Class<? extends MyBatisUnit> modletClass = (Class<? extends MyBatisUnit>) modletKit.getModletClass(e.getValue());
                    unitClassesMap.put(e.getKey(), modletClass);
                } catch (ModletNotFoundException ex) {
                    throw new MyBatisException(SqlSessionFactory.class.getName() + " provider could not be found: " + ex.getMessage());
                }
            }
            return new MyBatisSettings(unitClassesMap);
        });
    }


}
