package colesico.srv.mybatis.impl;

import colesico.core.config.ConfigKit;
import colesico.core.modlet.annotation.Initializer;
import colesico.core.module.Module;
import colesico.srv.mybatis.MyBatisUnit;
import colesico.srv.mybatis.exception.MyBatisException;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.inject.Provider;
import java.io.InputStream;

/**
 * Created by vvlarion on 31.03.2016.
 */
abstract public class AbstractMyBatisUnit implements MyBatisUnit {

    protected SqlSessionFactory sqlSessionFactory;
    protected final Provider<Module> moduleProv;

    public AbstractMyBatisUnit(Provider<Module> moduleProv) {
        this.moduleProv = moduleProv;
    }

    protected String getMyBatisConfigFileName(){
        return "mybatis-config.xml";
    }

    @Initializer
    protected void init(){
        try {
            String resourcePath = ConfigKit.getConfigFilePath(moduleProv.get(),getMyBatisConfigFileName());
            InputStream inputStream = AbstractMyBatisUnit.class.getResourceAsStream(resourcePath);
            if (inputStream==null) {
                throw new RuntimeException("MyBatis config file '"+resourcePath+"' not found");
            }
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        } catch (Exception ex){
            throw new MyBatisException("Error initializing SqlSessionFactory",ex);
        }
    }

    @Override
    public SqlSessionFactory getSqlSessionFactory() {
        return sqlSessionFactory;
    }
}
