package colesico.srv.mybatis.impl;

import org.apache.ibatis.session.SqlSession;

/**
 * Created by vvlarion on 31.03.2016.
 */
public class SqlSessionHolder {

    private final SqlSession sqlSession;
    private boolean rollback;
    private int openCounter;

    public SqlSessionHolder(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
        this.rollback = false;
        this.openCounter = 1;
    }

    public SqlSession getSqlSession() {
        return sqlSession;
    }


    public boolean getRollback() {
        return rollback;
    }

    public void setRollback() {
        this.rollback = true;
    }

    public int getOpenCounter() {
        return openCounter;
    }

    public int incOpenCouter() {
        openCounter++;
        return openCounter;
    }

    public int decOpenCounter() {
        openCounter--;
        return openCounter;
    }
}
