package colesico.srv.mybatis;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.TransactionIsolationLevel;

/**
 * Created by vvlarion on 30.03.2016.
 */
public interface MyBatisKit {

    String DEFAULT_UNIT_NAME = "default";

    String METHOD_OPEN ="open";
    String METHOD_CLOSE ="close";
    String METHOD_COMMIT="commit";
    String METHOD_ROLLBACK="rollback";

    void open(String unitName, ExecutorType executorType, TransactionIsolationLevel isolation);

    void close(String unitName);
    void close();

    void commit(String unitName);
    void commit();

    void rollback(String unitName);
    void rollback();

    <M>  M getMapper(String unitName, Class<M> mapperClass);
    <M>  M getMapper(Class<M> mapperClass);

    SqlSession getSession(String unitName);
    SqlSession getSession();

    boolean sessionExists(String unitName);
    boolean sessionExists();

}
