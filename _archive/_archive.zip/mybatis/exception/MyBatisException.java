package colesico.srv.mybatis.exception;

/**
 * Created by vvlarion on 31.03.2016.
 */
public class MyBatisException extends RuntimeException {
    public MyBatisException(String message) {
        super(message);
    }

    public MyBatisException(String message, Throwable cause) {
        super(message, cause);
    }
}
