/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.srv.mybatis.di;

import colesico.core.injector.DaggerModule;
import colesico.srv.mybatis.MyBatisKit;
import colesico.srv.mybatis.impl.MyBatisKitImpl;
import com.google.auto.service.AutoService;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

/**
 *
 * @author vvlarion
 */
@Module(library = true, complete = false,
        injects = {MyBatisKit.class}
)
@AutoService(DaggerModule.class)
public class MyBatisModule implements DaggerModule {

    @Provides
    @Singleton
    MyBatisKit provideMyBatisKit(MyBatisKitImpl impl) {
        return impl;
    }

}
