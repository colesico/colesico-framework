package colesico.srv.mybatis;

import org.apache.ibatis.session.SqlSessionFactory;

/**
 * Created by vvlarion on 30.03.2016.
 */
public interface MyBatisUnit {
    SqlSessionFactory getSqlSessionFactory();
}
