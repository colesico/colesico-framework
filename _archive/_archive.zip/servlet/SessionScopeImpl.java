package colesico.framework.servlet;

import colesico.framework.scope.SessionScope;
import colesico.framework.scope.ValueFactory;

import javax.servlet.http.HttpSession;
import java.util.Set;

/**
 * Created by vvlarion on 15.09.2016.
 */
public class SessionScopeImpl implements SessionScope {

    private final javax.servlet.http.HttpSession session;

    public SessionScopeImpl(HttpSession session) {
        this.session = session;
    }

    public HttpSession getSession() {
        return session;
    }

    @Override
    public void clear() {
        session.invalidate();
    }

    protected String toAttributeName(Object key){
        return key.getClass().getName()+"#"+key.hashCode();
    }

    @Override
    public Object get(Object o) {
        return session.getAttribute(toAttributeName(o));
    }

    @Override
    public void put(Object o, Object o1) {
        session.setAttribute(toAttributeName(o),o1);
    }

    @Override
    public Object provide(Object o, ValueFactory<?> valueFactory) {
        return null;
    }

    @Override
    public void remove(Object o) {
        session.removeAttribute(toAttributeName(o));
    }

    @Override
    public Set getKeys() {
        throw new UnsupportedOperationException("Not supported");
    }
}
