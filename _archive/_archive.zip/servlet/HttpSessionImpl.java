package colesico.framework.servlet;

import colesico.framework.http.HttpSession;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Created by vvlarion on 14.09.2016.
 */
public class HttpSessionImpl implements HttpSession{
    private final javax.servlet.http.HttpSession session;

    public HttpSessionImpl(javax.servlet.http.HttpSession session) {
        this.session = session;
    }

    public javax.servlet.http.HttpSession getSession() {
        return session;
    }

    @Override
    public void invalidate() {
        session.invalidate();
    }

    @Override
    public Object get(String attrName) {
        return session.getAttribute(attrName);
    }

    @Override
    public Object supply(String attrName, Supplier<?> attrFactory) {
        return null;
    }

    @Override
    public void set(String attrName, Object attrVal) {
        session.setAttribute(attrName,attrVal);
    }

    @Override
    public void remove(String attrName) {
        session.removeAttribute(attrName);
    }

    @Override
    public Set<String> getNames() {
        return new HashSet<>(Collections.list(session.getAttributeNames()));
    }
}
