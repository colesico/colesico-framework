package colesico.framework.servlet;

import colesico.framework.controller.ControllerKit;
import colesico.framework.controller.exception.UnmappedUriException;
import colesico.framework.http.*;
import colesico.framework.http.impl.HttpContextImpl;
import colesico.framework.injector.Injector;
import colesico.framework.scope.ProcessScope;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created by vvlarion on 06.09.2016.
 */
public class ActionFilter implements Filter {

    public static final String EXCLUDE_URIS_PARAM = "excludeURIs";

    protected ProcessScope processScope;
    protected ControllerKit controllerKit;
    protected HttpErrorHandler errorHandler;

    protected String[] excludePaths;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Injector injector = Injector.instance();
        this.processScope = injector.get(ProcessScope.class);
        this.controllerKit = injector.get(ControllerKit.class);
        this.errorHandler = injector.get(HttpErrorHandler.class);

        String excludePathsStr = filterConfig.getInitParameter(EXCLUDE_URIS_PARAM);
        if (excludePathsStr!=null) {
            excludePaths = StringUtils.split(excludePathsStr, ",");
            for (int i = 0; i < excludePaths.length; i++) {
                excludePaths[i] = StringUtils.trim(excludePaths[i]);
            }
        } else {
            excludePaths = new String[]{};
        }
    }


    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        String requestUri = httpServletRequest.getRequestURI();

        for (String excludePath : excludePaths) {
            if (requestUri.startsWith(excludePath)) {
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }
        }

        long startTime = System.nanoTime();

        HttpRequest httpRequest = new HttpRequestImpl(httpServletRequest);
        HttpResponse httpResponse = new HttpResponseImpl((HttpServletResponse) servletResponse);
        HttpSession httpSession = new HttpSessionImpl(httpServletRequest.getSession());
        HttpContext httpContext = new HttpContextImpl(httpRequest,httpResponse,httpSession);
        processScope.put(HttpContext.class,httpContext);

        try {
            controllerKit.invokeController(httpRequest.getRequestMethod(),httpRequest.getRequestURI());
        } catch (UnmappedUriException ex) {
            filterChain.doFilter(servletRequest, servletResponse);
        } catch (Exception ex) {
            errorHandler.handleException(ex);
        } finally {
            processScope.clear();
            long stopTime = System.nanoTime();
            long elapsedTime = stopTime - startTime;
            System.out.println("Execution time: "+ TimeUnit.NANOSECONDS.toMicros(elapsedTime)+" mcs");
        }
    }
}
