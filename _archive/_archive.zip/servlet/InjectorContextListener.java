package colesico.framework.servlet;

import colesico.framework.injector.Injector;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Created by vvlarion on 06.09.2016.
 */
public class InjectorContextListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        Injector.init();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        Injector.destroy();
    }
}
