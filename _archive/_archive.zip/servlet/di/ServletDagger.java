/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.framework.servlet.di;

import colesico.framework.config.ConfigLoader;
import colesico.framework.config.impl.ConfigLoaderImpl;
import colesico.framework.http.HttpContext;
import colesico.framework.i18n.LocaleKeeper;
import colesico.framework.i18n.impl.LocaleKeeperImpl;
import colesico.framework.injector.DaggerModule;
import colesico.framework.scope.SessionScope;
import colesico.framework.scope.impl.SessionScopeImpl;
import colesico.framework.servlet.HttpSessionImpl;
import com.google.auto.service.AutoService;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

/**
 *
 * @author vvlarion
 *
 */
@Module(library = true, complete = false,
        injects = {HttpContext.class, LocaleKeeper.class,SessionScope.class}
)
@AutoService(DaggerModule.class)
public class ServletDagger implements DaggerModule {

    public static final String SESSION_SCOPE_ATTRIBUTE="SESSION_SCOPE";

    @Provides
    SessionScope provideSessionScope(HttpContext httpContext){
        javax.servlet.http.HttpSession session = ((HttpSessionImpl)httpContext.getSession()).getSession();
        SessionScope scope;
        synchronized (session) {
            scope = (SessionScope) session.getAttribute(SESSION_SCOPE_ATTRIBUTE);
            if (scope == null) {
                scope = new SessionScopeImpl();
                session.setAttribute(SESSION_SCOPE_ATTRIBUTE,scope);
            }
        }
        return scope;
    }

    @Provides
    LocaleKeeper provideLocaleKeeper(SessionScope sesScope) {
        return (LocaleKeeper)sesScope.provide(LocaleKeeper.class,()->new LocaleKeeperImpl());
    }

    @Provides
    @Singleton
    ConfigLoader provideConfigLoader(ConfigLoaderImpl impl) {
        return impl;
    }
}
