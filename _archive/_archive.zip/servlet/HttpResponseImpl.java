package colesico.framework.servlet;


import colesico.framework.http.HttpCookie;
import colesico.framework.http.HttpResponse;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.ByteBuffer;

/**
 * Created by vvlarion on 06.09.2016.
 */
public class HttpResponseImpl implements HttpResponse {

    protected final HttpServletResponse response;
    private boolean responded;

    public HttpResponseImpl(HttpServletResponse response) {
        this.response = response;
        this.responded = false;
    }

    @Override
    public void setStatusCode(Integer code) {
        responded = true;
        response.setStatus(code);
    }

    @Override
    public void setContenType(String contentType) {
        responded = true;
        response.setContentType(contentType);
    }

    @Override
    public void setCookie(HttpCookie cookie) {
        responded = true;
        Cookie c = new Cookie(cookie.getName(), cookie.getValue());
        c.setDomain(cookie.getDomain());
        c.setPath(cookie.getPath());
        //TODO: доделать вычисление max age
        //c.setMaxAge();
        response.addCookie(c);
    }

    @Override
    public void sendText(String text,String contentType, Integer statusCode) {
        responded = true;
        if (contentType == null) {
            contentType = "text/html; charset=utf-8";
        }
        if (statusCode ==null ){
            statusCode = 200;
        }
        response.setContentType(contentType);
        response.setStatus(statusCode);
        try( PrintWriter out = response.getWriter()){
            out.print(text);
        } catch (Exception ex){
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void sendData(ByteBuffer byteBuffer, String contentType, Integer statusCode) {
        responded = true;
        if (contentType == null) {
            contentType = "application/octet-stream";
        }
        if (statusCode ==null ){
            statusCode = 200;
        }
        response.setContentType(contentType);
        response.setStatus(statusCode);
        try( OutputStream out = response.getOutputStream()){
            out.write(byteBuffer.array());
        } catch (Exception ex){
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void sendRedirect(String location, Integer code) {
        responded = true;
        if (code == null) {
            code = 302;
        }
        response.setStatus(code);
        try {
            response.sendRedirect(location);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public OutputStream getOutputStream() {
        responded = true;
        try {
            return response.getOutputStream();
        } catch (Exception ex){
            throw new RuntimeException(ex);
        }
    }

    @Override
    public boolean isResponded() {
        return responded;
    }
}
