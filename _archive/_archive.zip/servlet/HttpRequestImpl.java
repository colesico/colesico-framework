package colesico.framework.servlet;

import colesico.framework.http.HttpCookie;
import colesico.framework.http.HttpMethod;
import colesico.framework.http.HttpRequest;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by vvlarion on 06.09.2016.
 */
public class HttpRequestImpl implements HttpRequest {
    protected final HttpServletRequest request;

    public HttpRequestImpl(HttpServletRequest request) {
        this.request = request;
    }

    @Override
    public HttpMethod getRequestMethod() {
        switch (request.getMethod()) {
            case "GET":
                return HttpMethod.GET;
            case "POST":
                return HttpMethod.POST;
            case "PUT":
                return HttpMethod.PUT;
            case "PATCH":
                return HttpMethod.PATCH;
            case "DELETE":
                return HttpMethod.DELETE;
            case "HEAD":
                return HttpMethod.HEAD;
            case "CONNECT":
                return HttpMethod.CONNECT;
            case "TRACE":
                return HttpMethod.TRACE;
            case "OPTIONS":
                return HttpMethod.OPTIONS;
            default:
                throw new RuntimeException("Unsupported http method:" + request.getMethod());
        }
    }

    @Override
    public String getRequestScheme() {
        return request.getScheme();
    }

    @Override
    public String getHost() {
        return request.getServerName();
    }

    @Override
    public Integer getPort() {
        return request.getServerPort();
    }

    @Override
    public String getRequestURI() {
        return request.getRequestURI();
    }

    @Override
    public String getQueryString() {
        return request.getQueryString();
    }

    @Override
    public String getHeader(String name) {
        return request.getHeader(name);
    }

    @Override
    public String getParameter(String name) {
        return request.getParameter(name);
    }

    @Override
    public Set<String> getParameterNames() {
        return new HashSet<>(Collections.list(request.getParameterNames()));
    }

    @Override
    public InputStream getInputStream() {
        try {
            return request.getInputStream();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public Set<String> getCookieNames() {
        Set<String> result = new HashSet<>();
        for (Cookie c : request.getCookies()) {
            result.add(c.getName());
        }
        return result;
    }

    @Override
    public HttpCookie getCookie(String name) {
        for (Cookie c : request.getCookies()) {
            if (name.equals(c.getName())) {
                Date expdate = new Date();
                expdate.setTime(expdate.getTime() + (3600 * 1000));
                return new HttpCookie(c.getName(), c.getValue(), expdate, c.getPath(), c.getDomain());
            }
        }
        return null;
    }
}
