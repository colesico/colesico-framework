/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.layout;

import colesico.web.freemarker.Ftl;
import colesico.web.layout.LayoutMode;
import colesico.web.layout.LayoutRender;
import colesico.web.layout.WidgetDescriptor;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author vvlarion
 */
public class FtlLayoutRender implements LayoutRender {

    public static final String FRAMES_MAP_PARAM = "framesMap";
    public static final String FTL_DEFAULT_SUFFIX = "";
    public static final String FTL_CONF_SUFFIX = ".conf";

    protected final Ftl ftl;

    @Inject
    public FtlLayoutRender(Ftl ftl) {
        this.ftl = ftl;
    }

    @Override
    public String render(String layoutId, LayoutMode mode, Map<String, List<WidgetDescriptor>> framesMap) {
        Map<String, Object> params = new HashMap<>();
        params.put(FRAMES_MAP_PARAM, framesMap);

        String tmplSuffix;
        switch (mode) {
            case CONFIG:
                tmplSuffix = FTL_CONF_SUFFIX;
                break;
            case VIEW:
                tmplSuffix = FTL_DEFAULT_SUFFIX;
                break;
            default:
                throw new RuntimeException("Unsupported layout mode");
        }
        String baseName = layoutId;
        String layoutContents = ftl.process(baseName + tmplSuffix, params);
        return layoutContents;
    }

}
