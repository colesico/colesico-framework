/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colesico.web.freemarker.impl.models;

import colesico.web.http.HttpRequest;
import freemarker.template.SimpleScalar;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

import java.io.Serializable;

/**
 *
 * @author vvlarion
 */
public class HttpParamsModel implements TemplateHashModel, Serializable {

    private final HttpRequest httpRequest;

    public HttpParamsModel(HttpRequest httpRequest) {
        this.httpRequest = httpRequest;
    }

    @Override
    public TemplateModel get(String key) throws TemplateModelException {
        String value = httpRequest.getParameter(key);
        return value == null ? null : new SimpleScalar(value);
    }

    @Override
    public boolean isEmpty() throws TemplateModelException {
        return !httpRequest.getParameterNames().isEmpty();
    }
}
