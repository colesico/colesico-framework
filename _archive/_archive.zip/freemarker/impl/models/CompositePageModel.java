/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.models;

import colesico.web.widget.CompositePage;
import colesico.web.widget.PageFragment;
import freemarker.template.ObjectWrapper;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author vvlarion
 */
public class CompositePageModel implements TemplateHashModel, Serializable {

    protected static final String RES_REFS_KEY = "resRefs";

    private final CompositePage compositePage;
    private final ObjectWrapper ow;
    private final Map<String, TemplateModel> tmCache;

    public CompositePageModel(CompositePage compositePage, ObjectWrapper ow) {
        this.compositePage = compositePage;
        this.ow = ow;
        this.tmCache = new HashMap<>();
    }

    @Override
    public TemplateModel get(String key) throws TemplateModelException {
        TemplateModel tm = tmCache.get(key);
        if (tm != null) {
            return tm;
        }

        if (RES_REFS_KEY.equals(key)) {
            tm = ow.wrap(compositePage.getResourceReference());
        } else {
            PageFragment fragment = compositePage.getFragment(key);
            if (fragment == null) {
                return null;
            }
            tm = ow.wrap(fragment);
        }

        tmCache.put(key, tm);
        return tm;
    }

    @Override
    public boolean isEmpty() throws TemplateModelException {
        return false;
    }

}
