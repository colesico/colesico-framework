/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.models;

import colesico.srv.message.Message;
import colesico.srv.message.MessageKit;
import freemarker.template.*;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 *
 * @author vvlarion
 */
public class MessagesModel implements TemplateHashModel, Serializable{

    private final MessageKit messageKit;
    private final ObjectWrapper ow;

    public MessagesModel(MessageKit messageKit, ObjectWrapper ow) {
        this.messageKit = messageKit;
        this.ow = ow;
    }

    @Override
    public TemplateModel get(String key) throws TemplateModelException {
        if ("message_ids".equals(key)){
            SimpleSequence ss = new SimpleSequence(messageKit.getMessagesMap().keySet(), ow);
            return ss;
        }

        String[] keyParts = StringUtils.split(key, ":");
        Message msg;
        if (keyParts.length == 1) {
            msg = messageKit.getMessage(key);
        } else {
            msg = messageKit.getMessage(keyParts[1]);
            if (msg==null || !msg.getClass().getSimpleName().equals(keyParts[0])) {
                msg = null;
            }
        }
        if (msg == null) {
            return null;
        }
        return new SimpleScalar(msg.getText());
    }

    @Override
    public boolean isEmpty() throws TemplateModelException {
        return messageKit.isEmpty();
    }
}
