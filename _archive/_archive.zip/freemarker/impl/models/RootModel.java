/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colesico.web.freemarker.impl.models;

import freemarker.ext.beans.BeansWrapper;
import freemarker.template.TemplateHashModel;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author vvlarion
 */
public class RootModel implements TemplateHashModel, Serializable {

    private final BeansWrapper wrapper;

    private Map<String, TemplateModel> dataMap;

    public RootModel(BeansWrapper wrapper) {
        this.wrapper = wrapper;
        this.dataMap = new HashMap<>();
    }

    public void addAll(Map<String, Object> map) throws TemplateModelException {
        for (Map.Entry<String, Object> e : map.entrySet()) {
            dataMap.put(e.getKey(), wrapper.wrap(e.getValue()));
        }
    }

    public void put(String key, TemplateModel value) {
        dataMap.put(key, value);
    }

    @Override
    public TemplateModel get(String key) throws TemplateModelException {
        TemplateModel value = dataMap.get(key);
        return value;
    }

    @Override
    public boolean isEmpty() throws TemplateModelException {
        return false;
    }

}
