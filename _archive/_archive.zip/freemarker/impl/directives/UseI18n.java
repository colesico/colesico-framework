/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.directives;

import colesico.srv.i18n.I18n;
import colesico.web.freemarker.impl.models.I18nModel;
import freemarker.core.Environment;
import freemarker.template.*;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.Map;

/**
 *
 * @author vvlarion
 */
@Singleton
public class UseI18n implements TemplateDirectiveModel {

    public static final String VARNAME_I18N = "i18n";

    protected final Provider<I18n> i18nProv;

    @Inject
    public UseI18n(Provider<I18n> i18nProv) {
        this.i18nProv = i18nProv;
    }

    @Override
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body != null) {
            throw new TemplateModelException(
                    "This directive doesn't allow body.");
        }
        I18n i18n = i18nProv.get();
        env.setGlobalVariable(VARNAME_I18N, new I18nModel(i18n));
    }

}
