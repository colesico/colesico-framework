/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.directives;

import colesico.core.modlet.ModletKit;
import colesico.web.widget.WidgetKit;
import freemarker.core.Environment;
import freemarker.template.*;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static colesico.web.freemarker.impl.ConfigurationProvider.DIRECTIVE_RENDER_WIDGET;

/**
 *
 * @author vvlarion
 */
@Singleton
public class RenderWidget implements TemplateDirectiveModel {

    public static final String DIRPARAM_WIDGET_BEAN = "widgetModlet";
    public static final String DIRPARAM_WIDGET_ID = "widgetId";
    public static final String DIRPARAM_FRAGMENT_ID = "fragmentId";

    protected final ModletKit modletKit;
    protected final Provider<WidgetKit> wdgetKitProv;

    @Inject
    public RenderWidget(ModletKit modletKit, Provider<WidgetKit> wdgetKitProv) {
        this.modletKit = modletKit;
        this.wdgetKitProv = wdgetKitProv;
    }

    @Override
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body != null) {
            throw new TemplateModelException(
                    "This directive doesn't allow body.");
        }

        SimpleScalar modletParam = (SimpleScalar) params.get(DIRPARAM_WIDGET_BEAN);
        if (modletParam == null) {
            throw new RuntimeException("Attribute '" + DIRPARAM_WIDGET_BEAN + "' is not specified for the directive " + DIRECTIVE_RENDER_WIDGET);
        }
        String widgetModletClassName = modletParam.getAsString();

        SimpleScalar widgetIdParam = (SimpleScalar) params.get(DIRPARAM_WIDGET_ID);
        if (widgetIdParam == null) {
            throw new RuntimeException("Attribute '" + DIRPARAM_WIDGET_ID + "' is not specified for the directive " + DIRECTIVE_RENDER_WIDGET);
        }
        String widgetId = widgetIdParam.getAsString();

        SimpleScalar fragmentIdParam = (SimpleScalar) params.get(DIRPARAM_FRAGMENT_ID);
        if (fragmentIdParam == null) {
            throw new RuntimeException("Attribute '" + DIRPARAM_FRAGMENT_ID + "' is not specified for the directive " + DIRECTIVE_RENDER_WIDGET);
        }
        String fragmentId = fragmentIdParam.getAsString();

        WidgetKit widgetKit = wdgetKitProv.get();
        Map<String, Object> widgetParams = new HashMap<>();
        for (Object e : params.keySet()) {
            String key;
            if (e instanceof String) {
                key = (String) e;
            } else {
                continue;
            }
            Object v = params.get(e);
            if (v instanceof SimpleScalar) {
                widgetParams.put(key, ((TemplateScalarModel) v).getAsString());
            } else if (v instanceof SimpleNumber) {
                widgetParams.put(key, ((TemplateNumberModel) v).getAsNumber());
            } else if (TemplateBooleanModel.TRUE.equals(v)) {
                widgetParams.put(key, Boolean.TRUE);
            } else if (TemplateBooleanModel.FALSE.equals(v)) {
                widgetParams.put(key, Boolean.FALSE);
            }

        }
        widgetKit.renderWidget(widgetModletClassName, widgetId, fragmentId, widgetParams);
    }

}
