/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.directives;

import colesico.web.widget.CompositePage;
import freemarker.core.Environment;
import freemarker.template.*;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;

import static colesico.web.freemarker.impl.ConfigurationProvider.DIRECTIVE_LIST_RESOURCE_REF;

/**
 *
 * @author vvlarion
 */
@Singleton
public class ListResourceRef implements TemplateDirectiveModel {

    public static final String DIRPARAM_RESOURCE_TYPE = "type";
    public static final String VARNAME_RESOURCE_REFERENCE = "reference";

    protected final Provider<CompositePage> compositePageProv;

    @Inject
    public ListResourceRef(Provider<CompositePage> compositePageProv) {
        this.compositePageProv = compositePageProv;
    }

    @Override
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body == null) {
            throw new TemplateModelException(
                    "This directive need body.");
        }

        SimpleScalar typeParam = (SimpleScalar) params.get(DIRPARAM_RESOURCE_TYPE);
        if (typeParam == null) {
            throw new TemplateModelException("Attribute '" + DIRPARAM_RESOURCE_TYPE + "'  is not specified for the directive  " + DIRECTIVE_LIST_RESOURCE_REF);
        }
        String type = typeParam.getAsString();

        CompositePage compositePage = compositePageProv.get();

        List<String> refList = compositePage.getResourceReference().get(type);
        Writer out = env.getOut();
        for (String ref : refList) {
            env.setLocalVariable(VARNAME_RESOURCE_REFERENCE, new SimpleScalar(ref));
            body.render(out);
        }
    }

}
