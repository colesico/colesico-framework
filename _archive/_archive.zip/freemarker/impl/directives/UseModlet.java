/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.directives;

import colesico.core.libutil.CommonUtils;
import colesico.core.modlet.ModletKit;
import colesico.srv.i18n.I18n;
import colesico.web.freemarker.impl.models.I18nModel;
import freemarker.core.Environment;
import freemarker.ext.beans.BeansWrapper;
import freemarker.template.*;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.Map;

import static colesico.web.freemarker.impl.ConfigurationProvider.DIRECTIVE_RENDER_WIDGET;

/**
 * @author vvlarion
 */
@Singleton
public class UseModlet implements TemplateDirectiveModel {

    public static final String DIRPARAM_MODLET_CLASS = "class";
    public static final String DIRPARAM_MODLET_VAR = "var";

    protected final ModletKit modletKit;

    @Inject
    public UseModlet(ModletKit modletKit) {
        this.modletKit = modletKit;
    }


    @Override
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body != null) {
            throw new TemplateModelException(
                    "This directive doesn't allow body.");
        }

        SimpleScalar modletClassParam = (SimpleScalar) params.get(DIRPARAM_MODLET_CLASS);
        if (modletClassParam == null) {
            throw new RuntimeException("Attribute '" + DIRPARAM_MODLET_CLASS + "' is not specified for the directive " + DIRECTIVE_RENDER_WIDGET);
        }
        String modletClassName = modletClassParam.getAsString();

        Class modletClass = modletKit.getModletClass(modletClassName);

        SimpleScalar modletVarParam = (SimpleScalar) params.get(DIRPARAM_MODLET_VAR);
        String modletVarName;
        if (modletVarParam != null) {
            modletVarName = modletVarParam.getAsString();
        } else {
            modletVarName = CommonUtils.toIdentifier(modletClass);
        }

        BeansWrapper wrapper = (BeansWrapper) env.getObjectWrapper();

        Object modlet = modletKit.getModlet(modletClass);

        env.setGlobalVariable(modletVarName, wrapper.wrap(modlet));
    }

}
