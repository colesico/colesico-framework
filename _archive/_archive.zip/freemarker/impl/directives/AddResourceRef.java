/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.directives;

import colesico.web.widget.CompositePage;
import freemarker.core.Environment;
import freemarker.template.*;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.Map;

import static colesico.web.freemarker.impl.ConfigurationProvider.DIRECTIVE_ADD_RESOURCE_REF;

/**
 *
 * @author vvlarion
 */
@Singleton
public class AddResourceRef implements TemplateDirectiveModel {

    public static final String DIRPARAM_RESOURCE_TYPE = "type";
    public static final String DIRPARAM_RESOURCE_ID = "id";
    public static final String DIRPARAM_REFERENCE = "reference";
    public static final String DIRPARAM_DEPENDENCIES = "dependencies";

    protected final Provider<CompositePage> compositePageProv;

    @Inject
    public AddResourceRef(Provider<CompositePage> compositePageProv) {
        this.compositePageProv = compositePageProv;
    }

    @Override
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body != null) {
            throw new TemplateModelException(
                    "This directive doesn't allow body.");
        }

        SimpleScalar typeParam = (SimpleScalar) params.get(DIRPARAM_RESOURCE_TYPE);
        if (typeParam == null) {
            throw new TemplateModelException("Attribute '" + DIRPARAM_RESOURCE_TYPE + "' is not specified for the directive " + DIRECTIVE_ADD_RESOURCE_REF);
        }
        String type = typeParam.getAsString();

        SimpleScalar idParam = (SimpleScalar) params.get(DIRPARAM_RESOURCE_ID);
        if (idParam == null) {
            throw new TemplateModelException("Attribute '" + DIRPARAM_RESOURCE_ID + "' is not specified for the directive " + DIRECTIVE_ADD_RESOURCE_REF);
        }
        String id = idParam.getAsString();

        SimpleScalar referenceParam = (SimpleScalar) params.get(DIRPARAM_REFERENCE);
        if (referenceParam == null) {
            throw new TemplateModelException("Attribute '" + DIRPARAM_REFERENCE + "' is not specified for the directive " + DIRECTIVE_ADD_RESOURCE_REF);
        }
        String reference = referenceParam.getAsString();

        SimpleScalar dependenciesParam = (SimpleScalar) params.get(DIRPARAM_REFERENCE);
        String[] dependencies;
        if (dependenciesParam != null) {
            String dependenciesStr = dependenciesParam.getAsString();
            dependencies = StringUtils.split(dependenciesStr, ";");
        } else {
            dependencies = new String[]{};
        }

        CompositePage compositePage = compositePageProv.get();

        compositePage.getResourceReference().add(type, id, reference, dependencies);
    }

}
