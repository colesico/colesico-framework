/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl.directives;

import colesico.core.module.Module;
import colesico.srv.i18n.I18n;
import colesico.srv.message.MessageKit;
import colesico.web.freemarker.impl.models.CompositePageModel;
import colesico.web.freemarker.impl.models.HttpParamsModel;
import colesico.web.freemarker.impl.models.I18nModel;
import colesico.web.freemarker.impl.models.MessagesModel;
import colesico.web.http.HttpContext;
import colesico.web.widget.CompositePage;
import colesico.web.widget.WidgetKit;
import freemarker.core.Environment;
import freemarker.template.*;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.Map;

/**
 *
 * @author vvlarion
 */
@Singleton
public class WebPage implements TemplateDirectiveModel {

    public static final String VARNAME_MODULE_ID = "moduleId";
    public static final String VARNAME_MODULE_PATH = "modulePath";
    public static final String VARNAME_HTTP_PARAMS = "httpParams";
    public static final String VARNAME_I18N = "i18n";
    public static final String VARNAME_MESSAGES = "messages";
    public static final String VARNAME_COMPOSITE_PAGE = "compositePage";

    protected final Provider<HttpContext> contextProv;
    protected final Provider<I18n> i18nProv;
    protected final Provider<Module> moduleProv;
    protected final Provider<WidgetKit> widgetKitProv;
    protected final Provider<MessageKit> messageKitProv;
    protected final Provider<CompositePage> compositePageProv;

    @Inject
    public WebPage(Provider<HttpContext> contextProv, Provider<I18n> i18nProv, Provider<Module> moduleProv, Provider<WidgetKit> widgetKitProv, Provider<MessageKit> messageKitProv, Provider<CompositePage> compositePageProv) {
        this.contextProv = contextProv;
        this.i18nProv = i18nProv;
        this.moduleProv = moduleProv;
        this.widgetKitProv = widgetKitProv;
        this.messageKitProv = messageKitProv;
        this.compositePageProv = compositePageProv;
    }

    @Override
    public void execute(Environment env, Map params, TemplateModel[] loopVars, TemplateDirectiveBody body) throws TemplateException, IOException {
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body != null) {
            throw new TemplateModelException(
                    "This directive doesn't allow body.");
        }

        Module module = moduleProv.get();
        ObjectWrapper wrapper = env.getConfiguration().getObjectWrapper();
        HttpContext context = contextProv.get();
        I18n i18n = i18nProv.get();

        env.setGlobalVariable(VARNAME_MODULE_ID, new SimpleScalar(module.getId()));
        env.setGlobalVariable(VARNAME_MODULE_PATH, new SimpleScalar("/" + module.getId()));
        env.setGlobalVariable(VARNAME_HTTP_PARAMS, new HttpParamsModel(context.getRequest()));
        env.setGlobalVariable(VARNAME_I18N, new I18nModel(i18n));
        env.setGlobalVariable(VARNAME_MESSAGES, new MessagesModel(messageKitProv.get(), wrapper));
        env.setGlobalVariable(VARNAME_COMPOSITE_PAGE, new CompositePageModel(compositePageProv.get(), wrapper));
    }

}
