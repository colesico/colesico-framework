/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl;

import colesico.web.freemarker.impl.directives.*;
import colesico.web.freemarker.impl.directives.layout.BlockDirective;
import colesico.web.freemarker.impl.directives.layout.ExtendsDirective;
import colesico.web.freemarker.impl.directives.layout.PutDirective;
import freemarker.cache.TemplateLoader;
import freemarker.ext.beans.BeansWrapper;
import freemarker.ext.beans.BeansWrapperBuilder;
import freemarker.template.Configuration;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.TemplateModel;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.util.HashMap;
import java.util.Map;

/**
 * @author vvlarion
 */
@Singleton
public class ConfigurationProvider implements Provider<Configuration> {

    public static final String DIRECTIVE_USE_I18N = "useI18n";
    public static final String DIRECTIVE_USE_MODLET = "useModlet";
    public static final String DIRECTIVE_WEB_PAGE = "webPage";
    public static final String DIRECTIVE_LIST_RESOURCE_REF = "listResourceRef";
    public static final String DIRECTIVE_ADD_RESOURCE_REF = "addResourceRef";
    public static final String DIRECTIVE_RENDER_WIDGET = "renderWidget";
    public static final String DIRECTIVE_LAYOUT = "layout";


    protected final Configuration configuration;


    @Inject
    public ConfigurationProvider(FtlConfig ftlConfig, Provider<ModuleTemplateLoader> moduleTemplateLoaderProv,
                                 UseI18n useI18n, WebPage webPage, RenderWidget renderWidget, AddResourceRef addResourceRef,
                                 UseModlet useModlet) {


        configuration = new Configuration(Configuration.VERSION_2_3_23);
        TemplateLoader templateLoader = moduleTemplateLoaderProv.get();

        configuration.setTemplateLoader(templateLoader);
        configuration.setDefaultEncoding("UTF-8");
        configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        configuration.setTemplateUpdateDelayMilliseconds(ftlConfig.getFtlUpdateDelay() * 1000);

        try {
            configuration.setSharedVariable(DIRECTIVE_USE_I18N, useI18n);
            configuration.setSharedVariable(DIRECTIVE_USE_MODLET, useModlet);
            configuration.setSharedVariable(DIRECTIVE_WEB_PAGE, webPage);
            configuration.setSharedVariable(DIRECTIVE_RENDER_WIDGET, renderWidget);
            configuration.setSharedVariable(DIRECTIVE_ADD_RESOURCE_REF, addResourceRef);

            Map<String, TemplateModel> layoutDirectives = new HashMap<>();
            layoutDirectives.put("extends", new ExtendsDirective());
            layoutDirectives.put("block", new BlockDirective());
            layoutDirectives.put("put", new PutDirective());

            configuration.setSharedVariable(DIRECTIVE_LAYOUT, layoutDirectives);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

        BeansWrapperBuilder builder = new BeansWrapperBuilder(Configuration.VERSION_2_3_22);
        builder.setUseModelCache(true);
        builder.setExposeFields(true);
        BeansWrapper beansWrapper = builder.build();

        configuration.setSharedVariable(FtlProvider.VARNAME_STATICS, beansWrapper.getStaticModels());

        configuration.setObjectWrapper(beansWrapper);

    }

    @Override
    public Configuration get() {
        return configuration;
    }

}
