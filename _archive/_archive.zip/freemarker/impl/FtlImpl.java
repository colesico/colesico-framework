/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl;

import colesico.core.module.Module;
import colesico.web.freemarker.Ftl;
import colesico.web.freemarker.exception.FtlException;
import colesico.web.freemarker.impl.models.RootModel;
import colesico.web.resources.ResourcesKit;
import freemarker.ext.beans.BeansWrapper;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import javax.inject.Provider;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * @author vvlarion
 */
public class FtlImpl implements Ftl {

    protected final FtlConfig ftlConfig;
    protected final Configuration freemarkerConfig;
    protected final ResourcesKit resourcesKit;
    protected final Provider<Module> moduleProv;

    protected final BeansWrapper wrapper;
    protected RootModel dataModel;

    @Inject
    public FtlImpl(FtlConfig ftlConfig, Configuration freemarkerConfig, ResourcesKit resourcesKit, Provider<Module> moduleProv) {
        this.ftlConfig = ftlConfig;
        this.freemarkerConfig = freemarkerConfig;
        this.resourcesKit = resourcesKit;
        this.moduleProv = moduleProv;
        this.wrapper = (BeansWrapper) freemarkerConfig.getObjectWrapper();
    }


    protected void initDataModel() {
        dataModel = new RootModel(wrapper);
    }


    @Override
    public String process(String ftlPath, Map<String, Object> extDataModel) {
        try {
            if (StringUtils.isEmpty(ftlPath)) {
                throw new FtlException("ftlPath is empty");
            }
            if (!StringUtils.endsWith(ftlPath, ftlConfig.getDefaultFtlSuffix())) {
                ftlPath += ftlConfig.getDefaultFtlSuffix();
            }
            if (!ftlPath.startsWith("/~")){
                ftlPath = "/~"+moduleProv.get().getId()+ftlPath;
            }
            initDataModel();
            dataModel.addAll(extDataModel);
            Template template;
            ftlPath = resourcesKit.rewritePath(ftlPath);
            template = freemarkerConfig.getTemplate(ftlPath);
            StringWriter writer = new StringWriter();
            template.process(dataModel, writer);
            return writer.toString();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public String process(String ftlPath) {
        return process(ftlPath, new HashMap());
    }

}
