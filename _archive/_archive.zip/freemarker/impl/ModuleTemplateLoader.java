/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.impl;

import colesico.core.module.Module;
import colesico.core.module.ModuleKit;
import colesico.web.resources.ResourcesKit;
import freemarker.cache.URLTemplateLoader;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.net.URL;

/**
 * Templates loader with the ability to specify a module id
 *
 * @author Vladlen Larionov
 */
@Singleton
public class ModuleTemplateLoader extends URLTemplateLoader {

    public static final String FTL_BASE = "ftl";

    protected final String defaultFtlSuffix;

    protected final ModuleKit moduleKit;
    protected final Provider<Module> moduleProv;
    protected final ResourcesKit resourcesKit;

    @Inject
    public ModuleTemplateLoader(
            FtlConfig ftlConfig,
            ModuleKit moduleKit,
            Provider<Module> moduleProv,
            ResourcesKit resourcesKit) {
        this.moduleKit = moduleKit;
        this.moduleProv = moduleProv;
        this.resourcesKit = resourcesKit;
        this.defaultFtlSuffix = ftlConfig.getDefaultFtlSuffix();
    }

    @Override
    protected URL getURL(String ftlQuery) {
        if (StringUtils.isBlank(ftlQuery)) {
            return null;
        }

        String fullPath = null;

        if (!StringUtils.contains(ftlQuery, "~")) {
            if (StringUtils.startsWith(ftlQuery,"/")){
                fullPath = ftlQuery;
            } else {
                fullPath = "/"+ftlQuery;
            }
        } else {
            int slashInd = ftlQuery.indexOf("/");
            if (slashInd<0) {
                throw new RuntimeException("Invalid ftl query format:" + ftlQuery);
            }
            Module module = null;
            String moduleId = ftlQuery.substring(1,slashInd);
            if (StringUtils.isEmpty(moduleId)) {
                module = moduleProv.get();
            } else {
                module = moduleKit.getModuleById(moduleId);
            }

            String ftlRoot = module.getRootPath() + "/" + FTL_BASE;
            fullPath = ftlRoot + "/" + ftlQuery.substring(slashInd+1);
        }

        if (!StringUtils.endsWith(fullPath, defaultFtlSuffix)) {
            fullPath = fullPath + defaultFtlSuffix;
        }

        fullPath = resourcesKit.rewritePath(fullPath);

        return this.getClass().getResource(fullPath);
    }

}
