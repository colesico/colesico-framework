/*
 *  Copyright 20014-2015 Vladlen Larionov
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package colesico.web.freemarker.di;

import colesico.core.injector.DaggerModule;
import colesico.web.freemarker.Ftl;
import colesico.web.freemarker.impl.*;
import colesico.web.freemarker.impl.directives.*;
import colesico.web.freemarker.impl.layout.FtlLayoutRender;
import colesico.web.freemarker.impl.models.CompositePageModel;
import com.google.auto.service.AutoService;
import com.sun.webkit.WebPage;
import dagger.Module;
import dagger.Provides;
import freemarker.template.Configuration;

import javax.inject.Singleton;

/**
 *
 * @author vvlarion
 */
@Module(
        library = true,
        complete = false,
        injects = {Ftl.class,
            Configuration.class,
            FtlLayoutRender.class,
            AddResourceRef.class,
            RenderWidget.class,
            ListResourceRef.class,
            UseI18n.class,
            UseModlet.class,
            WebPage.class,
            ModuleTemplateLoader.class,
            CompositePageModel.class
        }
)
@AutoService(DaggerModule.class)
public class FreemarkerModule implements DaggerModule{

    @Provides
    Ftl provideFtl(FtlProvider prov) {
        return prov.get();
    }

    @Provides
    @Singleton
    FtlConfig provideFtlConfig(FtlConfigProvider prov) {
        return prov.get();
    }

    @Provides
    @Singleton
    Configuration provideConfiguration(ConfigurationProvider prov) {
        return prov.get();
    }
}
