/*
 * Copyright 20014-2018 Vladlen Larionov
 *             and others as noted
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package colesico.framework.pebble.internal;

import colesico.framework.translation.TranslationKit;
import com.mitchellbosecke.pebble.error.ParserException;
import com.mitchellbosecke.pebble.lexer.Token;
import com.mitchellbosecke.pebble.lexer.TokenStream;
import com.mitchellbosecke.pebble.node.RenderableNode;
import com.mitchellbosecke.pebble.parser.Parser;
import com.mitchellbosecke.pebble.tokenParser.TokenParser;

/**
 * @author Vladlen Larionov
 */
public class T9nBundleParser implements TokenParser {

    protected final TranslationKit t9n;

    public T9nBundleParser(TranslationKit t9n) {
        this.t9n = t9n;
    }

    @Override
    public String getTag() {
        return "t9nBundle";
    }

    @Override
    public RenderableNode parse(Token token, Parser parser) throws ParserException {
        TokenStream stream = parser.getStream();
        int lineNumber = token.getLineNumber();

        String bundle = null;

        // skip the "t9nBundle" register
        token = stream.next();

        // next register is String?
        if (token.test(Token.Type.STRING)) {
            bundle = token.getValue();
            token = stream.next();
        }
        // expect to see "%}"
        stream.expect(Token.Type.EXECUTE_END);
        return new T9nBundleNode(lineNumber, t9n, bundle);
    }
}
