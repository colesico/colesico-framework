/*
 * Copyright 20014-2018 Vladlen Larionov
 *             and others as noted
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package colesico.framework.pebble.internal;

import colesico.framework.translation.TranslationKit;
import com.mitchellbosecke.pebble.error.PebbleException;
import com.mitchellbosecke.pebble.extension.Filter;
import com.mitchellbosecke.pebble.template.EvaluationContext;
import com.mitchellbosecke.pebble.template.PebbleTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Vladlen Larionov
 */

public class T9nFilter implements Filter {

    public static final String FILTER_NAME ="t9n";
    protected final TranslationKit t9n;

    public T9nFilter(TranslationKit t9n) {
        this.t9n = t9n;
    }

    @Override
    public List<String> getArgumentNames() {
        return null;
    }

    @Override
    public Object apply(Object input, Map<String, Object> args, PebbleTemplate pebbleTemplate, EvaluationContext evaluationContext, int lineNumber) throws PebbleException {

        String str = (String) input;
        List params = new ArrayList();

        int i = 0;

        while (args.containsKey(String.valueOf(i))) {
            params.add(args.get(String.valueOf(i)));
            i++;
        }

        if (!params.isEmpty()) {
            List<?> list = (List<?>) params;
            return t9n.translate(str,list.toArray());
        } else {
            return t9n.translate(str);
        }
    }
}
