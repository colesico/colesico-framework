package colesico.framework.pebble.internal;

import colesico.framework.htmlrenderer.ResourceHtmlRenderer;
import colesico.framework.ioc.Message;
import colesico.framework.pebble.PebbleConfig;

import java.io.Writer;

public class PebbleRenderer extends ResourceHtmlRenderer<Object> {


    protected final PebbleProxy pebbleProxy;

    public PebbleRenderer(@Message PebbleConfig pebbleConfig, PebbleProxy pebbleProxy) {
        super(pebbleConfig.getTemplatesRootPath());
        this.pebbleProxy = pebbleProxy;
    }

    @Override
    protected final String doRender(String templateFullPath, Object model) {
        Writer writer = pebbleProxy.render(templateFullPath, model);
        return writer.toString();
    }
}
