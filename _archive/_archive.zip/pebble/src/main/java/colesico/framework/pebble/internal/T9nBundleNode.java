/*
 * Copyright 20014-2018 Vladlen Larionov
 *             and others as noted
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package colesico.framework.pebble.internal;

import colesico.framework.translation.TranslationKit;
import com.mitchellbosecke.pebble.extension.NodeVisitor;
import com.mitchellbosecke.pebble.node.AbstractRenderableNode;
import com.mitchellbosecke.pebble.template.EvaluationContextImpl;
import com.mitchellbosecke.pebble.template.PebbleTemplateImpl;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.Writer;

/**
 * @author Vladlen Larionov
 */
public final class T9nBundleNode extends AbstractRenderableNode {

    protected final TranslationKit t9n;
    protected final String bundle;

    public T9nBundleNode(int lineNumber, TranslationKit t9n, String bundle) {
        super(lineNumber);
        this.t9n = t9n;
        this.bundle = bundle;
    }

    @Override
    public void render(PebbleTemplateImpl pebbleTemplate, Writer writer, EvaluationContextImpl evaluationContext) throws IOException {
        if (StringUtils.isNotBlank(bundle)) {
            t9n.getDictionary(bundle);
        } else {
            throw new RuntimeException("Empty translation bundle at line:" + getLineNumber());
        }
    }

    @Override
    public void accept(NodeVisitor visitor) {
        visitor.visit(this);
    }
}
