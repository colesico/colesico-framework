package colesico.framework.pebble;

import colesico.framework.config.ConfigModel;
import colesico.framework.config.ConfigPrototype;
import colesico.framework.htmlrenderer.HtmlRenderer;

@ConfigPrototype(model = ConfigModel.CONTEXTUAL, target = HtmlRenderer.class)
abstract public class PebbleConfig {
    abstract public String getTemplatesRootPath();
}
