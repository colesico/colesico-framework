/*
 * Copyright 20014-2018 Vladlen Larionov
 *             and others as noted
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package colesico.framework.interceptor.codegen;


import colesico.framework.framlet.InvocationPhase;
import colesico.framework.framlet.codegen.model.ProxyMethodElement;
import colesico.framework.framlet.codegen.modulator.Modulator;
import colesico.framework.framlet.codegen.parser.ProcessorContext;
import colesico.framework.interceptor.annotation.Argument;
import colesico.framework.interceptor.annotation.Interceptor;
import colesico.framework.iocassist.StrUtils;
import colesico.framework.iocassist.codegen.CodegenException;
import colesico.framework.iocassist.codegen.CodegenUtils;
import com.google.auto.service.AutoService;
import com.squareup.javapoet.CodeBlock;
import com.squareup.javapoet.TypeName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.lang.model.element.*;
import javax.lang.model.type.*;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Vladlen Larionov
 */
@AutoService(Modulator.class)
public class InterceptModulator extends Modulator {

    public static final String INTERCEPTOR_FRAMLET_VAR = "interceptor";

    protected final Logger log = LoggerFactory.getLogger(InterceptModulator.class);

    @Override
    public void onInit(ProcessorContext context) {
        super.onInit(context);
    }

    @Override
    public void onProxyMethod(ProxyMethodElement proxyMethod) {
        super.onProxyMethod(proxyMethod);

        List<InterceptorElement> interceptorElements = getInterceptorElements(proxyMethod);

        if (interceptorElements.isEmpty()) {
            return;
        }

        if (proxyMethod.isPlain()) {
            String errMsg = "To use interceptions method should not be a plain method";
            throw CodegenException.of().message(errMsg).element(proxyMethod.getOriginMethod()).create();
        }

        for (InterceptorElement interceptorElement : interceptorElements) {
            TypeMirror retType = interceptorElement.getMethodName().getReturnType();
            if (retType instanceof NoType) {
                throw CodegenException.of().message("Interceptor method should not return void writer: " + interceptorElement.getClassType().getSimpleName().toString() + "." +
                        interceptorElement.getMethodName().getSimpleName().toString() + "(...)").element(interceptorElement.getMethodName()).create();
            }

            CodeBlock.Builder cb = CodeBlock.builder();
            TypeMirror interceptorType = interceptorElement.getClassType().asType();
            String interceptorProvName = StrUtils.firstCharToLowerCase(interceptorType.toString()) + "Prov";
            cb.addStatement("$T " + INTERCEPTOR_FRAMLET_VAR + "=$N.get()", TypeName.get(interceptorType), interceptorProvName);
            cb.addStatement("return " + INTERCEPTOR_FRAMLET_VAR + ".$N(", interceptorElement.getMethodName().getSimpleName().toString());
            List<? extends VariableElement> interceptorParams = getInterceptorParameters(interceptorElement);
            for (VariableElement interceptorParam : interceptorParams) {
                //TODO: check reader scope is InvocationContext

                InterceptorAttribute interceptorAttr = interceptorElement.getAttribute(interceptorParam.toString());
                if (interceptorAttr != null) {
                    checkParameterType(interceptorParam, interceptorAttr.getType(), interceptorElement);
                    CodeBlock c = generateAttribute(interceptorAttr, interceptorParam);
                    cb.add(c);
                    // TODO: not after last element
                    cb.add(",");
                } else {
                    InterceptorArgument interceptorArg = interceptorElement.getArgument(interceptorParam.toString());
                    if (interceptorArg != null) {
                        //TODO: generate pass reader
                    }
                    throw CodegenException.of().message("Interceptor parameter is not mapped to an attribute or argument:" + interceptorParam.toString()).element(interceptorParam).create();
                }
            }
            cb.add(");\n");
            proxyMethod.addInvocationHandler(interceptorElement.getInvocationPhase(), cb.build());
        }
    }

    public List<InterceptorElement> getInterceptorElements(ProxyMethodElement methodElement) {
        List<InterceptorElement> result = new ArrayList<>();
        List<? extends AnnotationMirror> annotations = methodElement.getOriginMethod().getAnnotationMirrors();
        for (AnnotationMirror annotation : annotations) {

            // Get meta annotation AccessControlConfig
            Interceptor interceptorAnnotation = annotation.getAnnotationType().asElement().getAnnotation(Interceptor.class);
            if (interceptorAnnotation == null) {
                continue;
            }

            // Определяем фазу генерации в кторой будет сгенерирован вызов метода контроля доступа
            InvocationPhase phase = interceptorAnnotation.phase();

            TypeMirror interceptorTypeMirror = null;
            try {
                interceptorAnnotation.clazz();
            } catch (MirroredTypeException mte) {
                interceptorTypeMirror = mte.getTypeMirror();
            }
            TypeElement interceptorType = processorContext.getProcessingEnv().getElementUtils().getTypeElement(interceptorTypeMirror.toString());
            if (interceptorType == null) {
                String errMsg = MessageFormat.format("Cant't find interceptor class: {0}", interceptorTypeMirror.toString());
                log.error(errMsg);
                throw CodegenException.of().message(errMsg).element(annotation.getAnnotationType().asElement()).create();
            }

            List<ExecutableElement> interceptorMethods = CodegenUtils.getProxiableMethods(processorContext.getProcessingEnv(), interceptorType, new Modifier[]{Modifier.PUBLIC});
            ExecutableElement interceptorMethod = null;
            String interceptorMethodName = interceptorAnnotation.methodName();
            for (ExecutableElement im : interceptorMethods) {
                if (!CodegenUtils.getMethodName(im).equals(interceptorMethodName)) {
                    continue;
                }
                interceptorMethod = im;
                break;
            }

            if (interceptorMethod == null) {
                String errMsg = MessageFormat.format("Cant't find interceptor method: {0}.{1}(...)", interceptorTypeMirror.toString(), interceptorMethodName);
                log.error(errMsg);
                throw CodegenException.of().message(errMsg).element(annotation.getAnnotationType().asElement()).create();
            }

            List<InterceptorAttribute> interceptorProperties = new ArrayList<>();
            List<InterceptorArgument> interceptorArguments = new ArrayList<>();

            for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> e : CodegenUtils.getAnnotationValuesWithDefaults(annotation).entrySet()) {
                Argument param = e.getKey().getAnnotation(Argument.class);
                String argName = e.getKey().getSimpleName().toString();
                Object argValue = e.getValue().getValue();

                if (param != null) {
                    if (!(argValue instanceof String)) {
                        String errMsg = MessageFormat.format("@{0} annotation can only be used on String field.", Argument.class.getSimpleName());
                        log.error(errMsg);
                        throw CodegenException.of().message(errMsg).element(e.getKey()).create();
                    }
                    interceptorArguments.add(new InterceptorArgument((String) argValue, argName));
                } else {
                    TypeMirror argType = e.getKey().getReturnType();
                    interceptorProperties.add(new InterceptorAttribute(argName, argType, argValue));
                }
            }

            InterceptorElement interceptionElement = new InterceptorElement(phase, interceptorType, interceptorMethod, interceptorProperties, interceptorArguments);
            result.add(interceptionElement);
        }
        return result;
    }

    /**
     * Возвращает список параметров текущего обрабатываемого метода (вызывающего метода)
     *
     * @return
     */
    protected Map<String, VariableElement> getProxyMethodParameters(ProxyMethodElement methodElement) {
        List<? extends VariableElement> methodParams = methodElement.getOriginMethod().getParameters();
        Map<String, VariableElement> result = new HashMap<>();
        for (VariableElement p : methodParams) {
            result.put(p.toString(), p);
        }
        return result;
    }

    protected List<? extends VariableElement> getInterceptorParameters(InterceptorElement interceptElement) {
        List<? extends VariableElement> methodParams = interceptElement.getMethodName().getParameters();
        return methodParams;
    }

    /**
     * Осуществляет проверку соответствия типа у параметра вызывающего (master) и вызываемого (interceptor) метода
     *
     * @param interceptorParameter
     * @param interceptElement
     */
    private void checkParameterType(VariableElement interceptorParameter, TypeMirror argumentType, InterceptorElement interceptElement) {
        TypeElement argumentTypeElm = processorContext.getElementUtils().getTypeElement(argumentType.toString());
        if ((argumentTypeElm != null && !processorContext.getTypeUtils().isAssignable(argumentTypeElm.asType(), interceptorParameter.asType()))
                || (argumentTypeElm == null && !interceptorParameter.asType().toString().equals(argumentType.toString()))) {

            String interceptorClassName = interceptElement.getClassType().getSimpleName().toString();
            String interceptorMethodName = interceptElement.getMethodName().getSimpleName().toString();
            String errMsg = MessageFormat.format("Parameter scope mismatch for interceptor method:{0}.{1}(... {2} {3} ...)",
                    interceptorClassName, interceptorMethodName, interceptorParameter.asType().toString(), interceptorParameter.toString());
            log.error(errMsg);
            throw CodegenException.of().message(errMsg).element(interceptorParameter).create();
        }
    }

    private final boolean isAssignable(TypeMirror type, Class target) {
        TypeMirror ct = processorContext.getElementUtils().getTypeElement(target.getName()).asType();
        return processorContext.getTypeUtils().isAssignable(type, ct);
    }

    private final CodeBlock generateDeclaredType(TypeMirror paramType, Object value) {
        CodeBlock.Builder cb = CodeBlock.builder();
        if (isAssignable(paramType, String.class)) {
            return cb.add("$S", value).build();
        } else if (isAssignable(paramType, Long.class)) {
            return cb.add("$L", value.toString() + "L").build();
        } else if (isAssignable(paramType, Integer.class)
                || isAssignable(paramType, Short.class)
                || isAssignable(paramType, Byte.class)) {
            return cb.add("$L", value.toString()).build();
        } else if (isAssignable(paramType, Double.class)) {
            return cb.add("$L", new BigDecimal((Double) value).toPlainString() + "d").build();
        } else if (isAssignable(paramType, Float.class)) {
            return cb.add("$L", new BigDecimal((Float) value).toPlainString() + "f").build();
        } else if (isAssignable(paramType, Character.class)) {
            return cb.add("$L", "'" + value.toString() + "'").build();
        } else if (isAssignable(paramType, Boolean.class)) {
            return cb.add((Boolean) value ? "true" : "false").build();
        } else if (isAssignable(paramType, Enum.class)) {
            return cb.add("$T.$N", TypeName.get(paramType), value.toString()).build();
        } else if (isAssignable(paramType, Class.class)) {
            return cb.add("$T.class", TypeName.get(paramType)).build();
        } else {
            return null;
        }
    }

    protected CodeBlock generateAttribute(InterceptorAttribute interceptAttribute, VariableElement interceptorParameter) {
        TypeMirror paramType = interceptorParameter.asType();
        if (paramType.getKind() == TypeKind.DECLARED) {
            CodeBlock cb = generateDeclaredType(paramType, interceptAttribute.getValue());
            if (cb == null) {
                String errMsg = MessageFormat.format("Unsupported interceptor parameter scope: {0}", paramType.toString());
                log.error(errMsg);
                throw CodegenException.of().message(errMsg).element(interceptorParameter).create();
            }
            return cb;
        } else if (paramType.getKind() == TypeKind.ARRAY) {
            ArrayType arrayParamType = (ArrayType) paramType;
            TypeMirror arrayItemsType = arrayParamType.getComponentType();
            Object[] values = (Object[]) interceptAttribute.getValue();
            CodeBlock.Builder cb = CodeBlock.builder();
            cb.add("new $T{", TypeName.get(paramType));
            boolean first = true;
            for (Object v : values) {
                if (!first) {
                    cb.add(",");
                }
                cb.add(generateDeclaredType(paramType, v));
                first = false;
            }
            cb.add("}");
            return cb.build();
        }
        String errMsg = MessageFormat.format("Unsupported interceptor parameter kind: {0}", paramType.getKind());
        log.error(errMsg);
        throw CodegenException.of().message(errMsg).element(interceptorParameter).create();
    }


}
