/*
 * Copyright 20014-2018 Vladlen Larionov
 *             and others as noted
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package colesico.framework.interceptor.codegen;

import colesico.framework.framlet.InvocationPhase;

import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import java.util.Collections;
import java.util.List;

/**
 * @author Vladlen Larionov
 */
public class InterceptorElement {
    protected final InvocationPhase invocationPhase;
    /**
     * Interceptor class
     */
    protected final TypeElement classType;
    /**
     * Interceptor method
     */
    protected final ExecutableElement methodName;

    /**
     * Constant values (eg values from annotation fields)
     */
    protected final List<InterceptorAttribute> attributes;
    /**
     * Values from master method parameters
     */
    protected final List<InterceptorArgument> arguments;


    public InterceptorElement(InvocationPhase phase,TypeElement handlerClass,  ExecutableElement methodName, List<InterceptorAttribute> attributes,
                              List<InterceptorArgument> arguments) {
        this.invocationPhase = phase;
        this.classType = handlerClass;
        this.methodName = methodName;
        this.attributes = attributes;
        this.arguments = arguments;
    }

    public InvocationPhase getInvocationPhase() {
        return invocationPhase;
    }

    public TypeElement getClassType() {
        return classType;
    }

    public ExecutableElement getMethodName() {
        return methodName;
    }

    public List<InterceptorAttribute> getAttributes() {
        return Collections.unmodifiableList(attributes);
    }

    public List<InterceptorArgument> getArguments() {
        return  Collections.unmodifiableList(arguments);
    }

    public InterceptorAttribute getAttribute(String name){
        for (InterceptorAttribute p:attributes){
            if (name.equals(p.getName())){
                return p;
            }
        }
        return null;
    }

    public InterceptorArgument getArgument(String name){
        for (InterceptorArgument p: arguments){
            if (name.equals(p.getName())){
                return p;
            }
        }
        return null;
    }
}
