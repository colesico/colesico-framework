package colesico.framework.rythm;

import java.util.Map;

/**
 * Created by vvlarion on 16.09.2016.
 */
public interface Rtl {
    String render(String tmplPath, Map<String, Object> dataModel);

    String render(String tmplPath);
}
