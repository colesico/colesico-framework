package colesico.framework.rythm.impl;

import colesico.framework.module.Module;
import colesico.framework.module.ModuleKit;
import colesico.framework.resource.ResourceKit;
import org.apache.commons.lang3.StringUtils;
import org.rythmengine.RythmEngine;
import org.rythmengine.resource.ITemplateResource;
import org.rythmengine.resource.ResourceLoaderBase;

import javax.inject.Provider;

/**
 * Created by vvlarion on 16.09.2016.
 */

public class ModuleResourceLoader extends ResourceLoaderBase {

    public static final String RTL_DIR ="rtl";
    public static final String TEMPLATE_SUFFIX =".html";

    protected final ModuleKit moduleKit;
    protected final Provider<Module> moduleProv;
    protected final ResourceKit resourceKit;

    protected RythmEngine engine;

    public ModuleResourceLoader(ModuleKit moduleKit, Provider<Module> moduleProv, ResourceKit resourceKit) {
        this.moduleKit = moduleKit;
        this.moduleProv = moduleProv;
        this.resourceKit = resourceKit;
    }

    @Override
    public String getResourceLoaderRoot() {
        return "/";
    }

    @Override
    public ITemplateResource load(String tmplQuery) {

        String fullPath;

        if (tmplQuery.startsWith("~")) {

            int slashInd = tmplQuery.indexOf("/");
            if (slashInd < 0) {
                throw new RuntimeException("Invalid template query format:" + tmplQuery);
            }
            Module module;

            String moduleId = tmplQuery.substring(1, slashInd);
            if (StringUtils.isEmpty(moduleId)) {
                module = moduleProv.get();
            } else {
                module = moduleKit.getModuleById(moduleId);
            }

            String tmplRoot = module.getRootPath() + "/" + RTL_DIR;

            fullPath = tmplRoot + "/" + tmplQuery.substring(slashInd + 1);
        } else {
            fullPath = tmplQuery;
        }

        if (!StringUtils.endsWith(fullPath, TEMPLATE_SUFFIX)) {
            fullPath = fullPath + TEMPLATE_SUFFIX;
        }

        fullPath = resourceKit.rewriteResource(fullPath);

        return new ModuleTemplateResource(fullPath, this);
    }


}

