package colesico.framework.rythm.impl;

import org.apache.commons.lang3.StringUtils;
import org.rythmengine.extension.ITemplateResourceLoader;
import org.rythmengine.resource.TemplateResourceBase;
import org.rythmengine.utils.IO;

import java.net.URL;

/**
 * Created by vvlarion on 16.09.2016.
 */
public class ModuleTemplateResource extends TemplateResourceBase {

    private final URL url;
    private final String key;

    public ModuleTemplateResource(String path, ITemplateResourceLoader loader) {
        super(loader);

        this.key = path;
        ClassLoader cl = loader.getEngine().classLoader();
        this.url = cl.getResource(path.substring(1));
    }

    @Override
    public Object getKey() {
        return key;
    }

    @Override
    public boolean isValid() {
        return url != null;
    }

    @Override
    public String getSuggestedClassName() {
        String className = pathToClassName(StringUtils.removeEnd(this.key, ModuleResourceLoader.TEMPLATE_SUFFIX));
        return className;
    }

    protected final String pathToClassName(String path) {
        StringBuilder result = new StringBuilder();
        boolean toUpper = true;
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '/') {
                toUpper = true;
                continue;
            }
            if (c == '-') {
                toUpper = true;
                continue;
            }
            if (toUpper) {
                result.append(Character.toUpperCase(c));
                toUpper = false;
                continue;
            }
            result.append(c);
        }
        return result.toString();
    }

    @Override
    protected long defCheckInterval() {
        return -1;
    }

    @Override
    protected long lastModified() {
        if (getEngine().isProdMode()) {
            return 0;
        }
        String fileName;
        if ("file".equals(url.getProtocol())) {
            fileName = url.getFile();
        } else if ("jar".equals(url.getProtocol())) {
            try {
                java.net.JarURLConnection jarUrl = (java.net.JarURLConnection) url.openConnection();
                fileName = jarUrl.getJarFile().getName();
            } catch (Exception e) {
                return System.currentTimeMillis() + 1;
            }
        } else {
            return System.currentTimeMillis() + 1;
        }

        java.io.File file = new java.io.File(fileName);
        return file.lastModified();
    }

    @Override
    protected String reload() {
        return IO.readContentAsString(url);
    }
}
