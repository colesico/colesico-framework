package colesico.framework.rythm.impl;

import colesico.framework.module.Module;
import colesico.framework.module.ModuleKit;
import colesico.framework.resource.ResourceKit;
import colesico.framework.rythm.Rtl;
import org.rythmengine.RythmEngine;
import org.rythmengine.extension.ITemplateResourceLoader;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by vvlarion on 16.09.2016.
 */
@Singleton
public class RtlImpl implements Rtl {

    protected final RythmEngine engine;

    @Inject
    public RtlImpl(ModuleKit moduleKit, Provider<Module> moduleProv, ResourceKit resourceKit) {
        ModuleResourceLoader loader = new ModuleResourceLoader(moduleKit,moduleProv,resourceKit);
        List<ITemplateResourceLoader> resLoaders = new ArrayList<>();
        resLoaders.add(loader);

        Map<String,Object> config = new HashMap<>();
        config.put("resource.loader.impls",resLoaders);
        //TODO: читать из конфига
        //config.put("engine.mode","dev");
        engine = new RythmEngine(config);

    }

    @Override
    public String render(String tmplPath, Map<String, Object> dataModel) {
        return engine.render(tmplPath,dataModel);
    }

    @Override
    public String render(String tmplPath) {
        return engine.render(tmplPath);
    }
}
