module colesico.framework.rocker {
    requires transitive colesico.framework.htmlrenderer;

    //requires org.slf4j;
    requires slf4j.api;

    requires org.apache.commons.lang3;

    requires transitive rocker.runtime;

    // classes
    exports colesico.framework.rocker;
    exports colesico.framework.rocker.internal to colesico.framework.ioc;
}
