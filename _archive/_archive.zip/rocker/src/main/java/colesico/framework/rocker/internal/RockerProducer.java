package colesico.framework.rocker.internal;

import colesico.framework.htmlrenderer.HtmlRenderer;
import colesico.framework.ioc.*;
import colesico.framework.rocker.FrameworkAssist;
import colesico.framework.rocker.RockerConfig;

@Producer(Rank.RANK_MINOR)
@Produce(FrameworkAssist.class)
@Produce(RockerRenderer.class)
public class RockerProducer {

    @Unscoped
    @Classed(RockerConfig.class)
    public HtmlRenderer getHtmlRender(RockerRenderer impl) {
        return impl;
    }

}
