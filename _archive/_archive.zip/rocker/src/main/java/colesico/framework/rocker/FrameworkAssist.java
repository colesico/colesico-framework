package colesico.framework.rocker;

import colesico.framework.translation.TranslationKit;

import javax.inject.Singleton;

@Singleton
public class FrameworkAssist {

    public final TranslationKit t9n;

    public FrameworkAssist(TranslationKit t9n) {
        this.t9n = t9n;
    }


}
