package colesico.framework.rocker;

import com.fizzed.rocker.RockerModel;
import com.fizzed.rocker.RockerTemplate;
import com.fizzed.rocker.RockerUtils;
import com.fizzed.rocker.runtime.DefaultRockerTemplate;

abstract public class FrameworkRockerTemplate extends DefaultRockerTemplate {

    public FrameworkAssist assist;

    public FrameworkRockerTemplate(RockerModel model) {
        super(model);
    }

    public FrameworkAssist getAssist() {
        return assist;
    }

    public void setAssist(FrameworkAssist assist) {
        this.assist = assist;
    }

    @Override
    protected void __associate(RockerTemplate template) {
        super.__associate(template);
        FrameworkRockerTemplate thatTemplate = RockerUtils.requireTemplateClass(template, FrameworkRockerTemplate.class);
        this.setAssist(thatTemplate.getAssist());
    }
}
