package colesico.framework.rocker.internal;

import colesico.framework.assist.StrUtils;
import colesico.framework.htmlrenderer.HtmlRenderer;
import colesico.framework.ioc.Message;
import colesico.framework.ioc.Unscoped;
import colesico.framework.rocker.FrameworkAssist;
import colesico.framework.rocker.FrameworkRockerTemplate;
import colesico.framework.rocker.RockerConfig;
import colesico.framework.weblet.HtmlResponse;
import com.fizzed.rocker.*;
import com.fizzed.rocker.runtime.ArrayOfByteArraysOutput;

@Unscoped
public class RockerRenderer implements HtmlRenderer<String, Object> {

    public final String FILE_SUFFIX = ".rocker.html";
    public final String MODEL_VAR_NAME = "tm";

    protected final String templatesRootPath;

    protected final FrameworkAssist assist;

    public RockerRenderer(@Message RockerConfig config, FrameworkAssist assist) {
        this.templatesRootPath = config.getTemplatesRootPath();
        this.assist = assist;
    }

    @Override
    public HtmlResponse render(String templateName, Object model) {
        String templatePath = StrUtils.concatPath(templatesRootPath, templateName, "/") + FILE_SUFFIX;
        BindableRockerModel rockerModel = Rocker.template(templatePath);
        rockerModel.bind(MODEL_VAR_NAME, model);

        ArrayOfByteArraysOutput out = rockerModel.render(
                ArrayOfByteArraysOutput.FACTORY,
                template -> {
                    if (template instanceof FrameworkRockerTemplate) {
                        FrameworkRockerTemplate tmpl = (FrameworkRockerTemplate) template;
                        tmpl.setAssist(assist);
                    }
                }
        );

        String content = out.toString();
        return new HtmlResponse(content);

    }
}
