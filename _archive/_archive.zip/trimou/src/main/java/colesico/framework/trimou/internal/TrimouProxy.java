package colesico.framework.trimou.internal;

import colesico.framework.ioc.Polysupplier;
import colesico.framework.trimou.TrimouOptionsConfig;
import org.trimou.Mustache;
import org.trimou.engine.MustacheEngine;
import org.trimou.engine.MustacheEngineBuilder;
import org.trimou.engine.config.EngineConfigurationKey;
import org.trimou.exception.MustacheException;
import org.trimou.util.ImmutableMap;

import javax.inject.Singleton;
import java.io.StringWriter;
import java.io.Writer;

@Singleton
public class TrimouProxy {

    public static final String TM_VAR = "tm";

    protected final MustacheEngine mustacheEngine;

    public TrimouProxy(Polysupplier<TrimouOptionsConfig> optionSup,
                       TrimouTemplateLocator templateLocator,
                       RequestLocaleSupport requestLocaleSupport,
                       T9nUseHelper t9nBundleHelper,
                       T9nHelper t9nHelper,
                       T9nFormatHelper t9nFormatHelper
    ) {

        final MustacheEngineBuilder builder = MustacheEngineBuilder.newBuilder();
        builder.setProperty(EngineConfigurationKey.PRECOMPILE_ALL_TEMPLATES, true);
        builder.setLocaleSupport(requestLocaleSupport);
        builder.addTemplateLocator(templateLocator);
        builder.registerHelper(T9nUseHelper.HELPER_NAME,t9nBundleHelper);
        builder.registerHelper(T9nHelper.HELPER_NAME,t9nHelper);
        builder.registerHelper(T9nFormatHelper.HELPER_NAME,t9nFormatHelper);

        optionSup.forEach(options -> options.applyOptions(builder), null);
        this.mustacheEngine = builder.build();
    }

    public Writer render(String templatePath, Object templateModel) {
        Mustache mustache = mustacheEngine.getMustache(templatePath);
        if (mustache == null) {
            throw new MustacheException("Template not found: " + templatePath);
        }
        StringWriter writer = new StringWriter();
        mustache.render(writer, ImmutableMap.of(TM_VAR, templateModel));
        return writer;
    }
}
