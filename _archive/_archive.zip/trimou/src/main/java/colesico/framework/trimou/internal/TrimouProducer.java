package colesico.framework.trimou.internal;

import colesico.framework.htmlrenderer.HtmlRenderer;
import colesico.framework.ioc.*;
import colesico.framework.trimou.TrimouConfig;

@Producer(Rank.RANK_MINOR)
@Produce(TrimouProxy.class)
@Produce(TrimouRenderer.class)
@Produce(RequestLocaleSupport.class)
@Produce(TrimouTemplateLocator.class)
@Produce(T9nUseHelper.class)
@Produce(T9nHelper.class)
@Produce(T9nFormatHelper.class)
public class TrimouProducer {

    @Classed(TrimouConfig.class)
    @Unscoped
    public HtmlRenderer getHtmlRenderer(TrimouRenderer impl) {
        return impl;
    }
}
