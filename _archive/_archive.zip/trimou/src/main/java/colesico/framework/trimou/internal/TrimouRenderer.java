package colesico.framework.trimou.internal;

import colesico.framework.htmlrenderer.ResourceHtmlRenderer;
import colesico.framework.ioc.Message;
import colesico.framework.ioc.Unscoped;
import colesico.framework.trimou.TrimouConfig;

import java.io.Writer;

@Unscoped
public class TrimouRenderer extends ResourceHtmlRenderer<Object> {

    protected final TrimouProxy trimouPproxy;

    public TrimouRenderer(@Message TrimouConfig config,
                          TrimouProxy trimouPproxy) {
        super(config.getTemplatesRootPath());
        this.trimouPproxy = trimouPproxy;
    }

    @Override
    protected String doRender(String templateFullPath, Object model) {
        Writer writer = trimouPproxy.render(templateFullPath, model);
        return writer.toString();
    }
}
