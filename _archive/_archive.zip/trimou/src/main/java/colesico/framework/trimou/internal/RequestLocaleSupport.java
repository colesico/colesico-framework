package colesico.framework.trimou.internal;

import org.trimou.engine.locale.DefaultLocaleSupport;

import javax.inject.Provider;
import javax.inject.Singleton;
import java.util.Locale;

@Singleton
public class RequestLocaleSupport extends DefaultLocaleSupport {

    private final Provider<Locale> localeProv;

    public RequestLocaleSupport(Provider<Locale> localeProv) {
        this.localeProv = localeProv;
    }

    @Override
    public Locale getCurrentLocale() {
        return localeProv.get();
    }

}
