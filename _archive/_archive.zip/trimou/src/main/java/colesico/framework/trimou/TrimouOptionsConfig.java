package colesico.framework.trimou;

import colesico.framework.config.ConfigModel;
import colesico.framework.config.ConfigPrototype;
import org.trimou.engine.MustacheEngineBuilder;

@ConfigPrototype(model = ConfigModel.POLYVARIANT)
abstract public class TrimouOptionsConfig {
    abstract public void applyOptions(MustacheEngineBuilder builder);
}
