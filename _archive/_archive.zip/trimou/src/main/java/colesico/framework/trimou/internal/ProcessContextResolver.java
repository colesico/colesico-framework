/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package colesico.framework.trimou.internal;

import colesico.framework.ioc.StringKey;
import colesico.framework.ioc.ThreadScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.trimou.engine.resolver.AbstractResolver;
import org.trimou.engine.resolver.ReflectionResolver;
import org.trimou.engine.resolver.ResolutionContext;

import javax.inject.Inject;
import javax.inject.Singleton;

import static org.trimou.engine.priority.Priorities.rightAfter;

/**
 * @author Vladlen Larionov
 */
@Singleton
public class ProcessContextResolver extends AbstractResolver {


    protected final Logger log = LoggerFactory.getLogger(ProcessContextResolver.class);
    public static final int PC_RESOLVER_PRIORITY = rightAfter(ReflectionResolver.REFLECTION_RESOLVER_PRIORITY);

    protected final ThreadScope threadScope;

    @Inject
    public ProcessContextResolver(ThreadScope threadScope) {
        super(PC_RESOLVER_PRIORITY);
        this.threadScope = threadScope;
    }


    @Override
    public Object resolve(Object contextObject, String name, ResolutionContext resolutionContext) {
        if (contextObject != null) {
            return null;
        }

        return threadScope.get(new StringKey<>(name));
    }
}
