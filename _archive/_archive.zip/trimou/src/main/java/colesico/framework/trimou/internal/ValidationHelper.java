/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package colesico.framework.trimou.internal;

import colesico.framework.validation.ValidationError;
import org.trimou.handlebars.BasicSectionHelper;
import org.trimou.handlebars.Options;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
* @author Vladlen Larionov
*/
@Singleton
public class ValidationHelper extends BasicSectionHelper {

    public static final String HELPER_NAME="validation";
    public static final String ERR_ITEMS_VAR ="errorItems";

    @Inject
    public ValidationHelper() {

    }

    @Override
    public void execute(Options options) {
        String subject=options.getParameters().get(0).toString();
        Map<String, List<ValidationError>> errorsMap = (Map<String, List<ValidationError>>) options.getParameters().get(1);

        if (errorsMap==null){
            return;
        }

        List<ValidationError> errorItems = errorsMap.get(subject);

        if (errorItems!=null) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ERR_ITEMS_VAR, errorItems);
            options.push(contextParams);
            options.fn();
            options.pop();
        }
    }

    @Override
    protected int numberOfRequiredParameters() {
        return 2;
    }
}
