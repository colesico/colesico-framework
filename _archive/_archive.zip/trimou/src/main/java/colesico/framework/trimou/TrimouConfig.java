package colesico.framework.trimou;

import colesico.framework.config.ConfigModel;
import colesico.framework.config.ConfigPrototype;
import colesico.framework.htmlrenderer.HtmlRenderer;

@ConfigPrototype(model = ConfigModel.CONTEXTUAL, target = HtmlRenderer.class)
abstract public class TrimouConfig {
    abstract public String getTemplatesRootPath();
}
