/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package colesico.framework.trimou.internal;

import colesico.framework.translation.TranslationKit;
import org.trimou.handlebars.BasicValueHelper;
import org.trimou.handlebars.Options;
import org.trimou.util.Arrays;

import javax.inject.Singleton;
import java.util.List;

/**
* @author Vladlen Larionov
*/
@Singleton
public class T9nFormatHelper extends BasicValueHelper{

    public static final String HELPER_NAME="t9nFormat";

    protected final TranslationKit t9n;

    public T9nFormatHelper(TranslationKit t9n) {
        this.t9n = t9n;
    }

    @Override
    public void execute(Options options) {
        String str = options.getParameters().get(0).toString();
        Object[] formatParams = getFormatParams(options.getParameters());
        /*
        String text = t9n.translate(str,formatParams);
        append(options,text);
        */
    }

    private Object[] getFormatParams(List<Object> params) {
        if (params.size() > 1) {
            return params.subList(1, params.size()).toArray();
        }
        return Arrays.EMPTY_OBJECT_ARRAY;
    }



}
