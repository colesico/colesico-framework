package colesico.framework.trimou.internal;

import colesico.framework.translation.Dictionary;
import org.trimou.engine.resolver.AbstractResolver;
import org.trimou.engine.resolver.ResolutionContext;

public class T9nDictionaryResolver extends AbstractResolver {

    public T9nDictionaryResolver(int priority) {
        super(priority);
    }

    @Override
    public Object resolve(Object contextObject, String name, ResolutionContext resolutionContext) {
        if (contextObject == null) {
            return null;
        }

        if (!(contextObject instanceof Dictionary)) {
            return null;
        }

        Dictionary dictionary = (Dictionary) contextObject;
        return dictionary.get(name);
    }
}
