/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package colesico.framework.trimou.internal;

import colesico.framework.resource.ResourceKit;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.trimou.engine.locator.TemplateLocator;
import org.trimou.exception.MustacheException;
import org.trimou.exception.MustacheProblem;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Set;

/**
 * @author Vladlen Larionov
 */
@Singleton
public class TrimouTemplateLocator implements TemplateLocator {


    public static final String TEMPLATE_SUFFIX = ".html";
    public static final String TEMPLATE_ENCODING = "UTF-8";

    protected final ResourceKit resourceKit;
    protected final Logger logger = LoggerFactory.getLogger(TrimouTemplateLocator.class);

    protected static final int DEFAULT_PRIORITY = 1;

    @Inject
    public TrimouTemplateLocator(ResourceKit resourceKit) {
        this.resourceKit = resourceKit;
    }

    @Override
    public Reader locate(String templatePath) {
        String resourcePath = getResourcePath(templatePath);
        Reader reader = null;
        try {
            Enumeration<URL> resources = getClass().getClassLoader().getResources(resourcePath);
            while (resources.hasMoreElements()) {
                URL resource = resources.nextElement();
                if (reader != null) {
                    logger.warn("Duplicit template for " + resourcePath + " ignored: " + resource);
                } else {
                    reader = new InputStreamReader(resource.openStream(), TEMPLATE_ENCODING);
                    logger.debug("Template " + resourcePath + " located: " + resource);
                }
            }
        } catch (IOException e) {
            throw new MustacheException(MustacheProblem.TEMPLATE_LOADING_ERROR, e);
        }
        return reader;

    }

    protected String getResourcePath(String templatePath) {
        String resourcePath = templatePath;

        if (!StringUtils.endsWith(resourcePath, TEMPLATE_SUFFIX)) {
            resourcePath = resourcePath + TEMPLATE_SUFFIX;
        }

        resourcePath = resourceKit.rewrite(resourcePath);
        return resourcePath;
    }

    @Override
    public Set<String> getAllIdentifiers() {
        return Collections.emptySet();
    }

    @Override
    public int getPriority() {
        return DEFAULT_PRIORITY;
    }
}
