module colesico.framework.trimou {
    requires transitive colesico.framework.htmlrenderer;

    //requires org.slf4j;
    requires slf4j.api;
    requires org.apache.commons.lang3;

    requires transitive trimou.core;

    // classes
    exports colesico.framework.trimou;
    exports colesico.framework.trimou.internal to colesico.framework.ioc;
}
