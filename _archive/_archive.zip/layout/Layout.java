/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout;

import java.util.List;
import java.util.Map;

/**
 *
 * @author Vladlen Larionov
 */
public interface Layout {

     String LAYOUT_FRAGMENT_ID = "layout";

    /**
     * Creates a widget and place it in the layout
     *
     * @param location
     * @param widgetDescriptor
     */
    void createWidget(WidgetLocation location, WidgetReference widgetDescriptor);

    /**
     * Calls widget editing invoker
     * @param location
     * @param callbackModletClass
     */
    void configureWidget(WidgetLocation location, Class<? extends LayoutObserver> callbackModletClass);

    void relocateWidget(WidgetLocation srcLocation, WidgetLocation dstLocation);

    /**
     * Removes widgets with layout and calls wiget's removal invoker
     * @param location
     * @return
     */
    WidgetDescriptor removeWidget(WidgetLocation location);

    void alter(LayoutReference layoutRef);

    /**
     * Returns the current layout mode
     *
     * @return
     */
    LayoutMode getMode();

    void setMode(LayoutMode mode);

    /**
     * Returns the current state of layout
     *
     * @return
     */
    LayoutImage exportImage();

    void importImage(LayoutImage layoutImg);

    /**
     * Returns the layout frames getValue
     *
     * @return
     */
    Map<String, List<WidgetDescriptor>> getSoltsMap();

    Class<? extends LayoutRender> getRenderClass();

    String getLayoutId();

    void render();

}
