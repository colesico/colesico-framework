/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout.impl;

import colesico.framework.injector.Injector;
import colesico.framework.layout.LayoutKit;
import colesico.framework.layout.LayoutReference;
import colesico.framework.layout.LayoutRender;
import colesico.framework.layout.WidgetReference;
import colesico.framework.layout.exception.LayoutException;
import org.apache.commons.io.IOUtils;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 *
 * @author Vladlen Larionov
 */
@Singleton
public class LayoutKitImpl implements LayoutKit {

    public static final String LAYOUTS_CATALOG_PATH = "META-INF/layouts.json";

    protected final Injector injector;

    /**
     * Loads module with input strem
     *
     * @param is input stream of utf-8 json text
     * @return
     * @throws Exception
     */
    protected List<LayoutReference> fromInputStream(InputStream is) throws Exception {
        byte[] fileBytes = IOUtils.toByteArray(is);
        String json = new String(fileBytes, "UTF-8");
        return fromString(json);
    }

    /**
     * Unserialize json string to array of modules
     *
     * @param json
     * @return
     */
    protected List<LayoutReference> fromString(String json) {
        throw new UnsupportedOperationException("Not refactored yet");
        /*
        try {
            //TODO:
            //LayoutReferenceJson[] refsJson = JsonConverter.fromJson(LayoutReferenceJson[].class, json);
            LayoutReferenceJson[] refsJson = null;
            List<LayoutReference> result = new ArrayList<>();
            for (LayoutReferenceJson refJson : refsJson) {
                if (StringUtils.isBlank(refJson.getRender())) {
                    throw new RuntimeException("Layout render is empty during parsing json text:" + json);
                }
                if (StringUtils.isBlank(refJson.getIconUrl())) {
                    throw new RuntimeException("Layout icon URL is empty during parsing json text:" + json);
                }
                if (StringUtils.isBlank(refJson.getDefaultFrameId())) {
                    throw new RuntimeException("Default frame ID  is empty during parsing json text:" + json);
                }
                if (refJson.getFrameIds() == null || refJson.getFrameIds().length == 0) {
                    throw new RuntimeException("Layout frame IDs  is empty during parsing json text:" + json);
                }

                result.add(new LayoutReference(
                        refJson.getRender(),
                        refJson.getLayoutId(),
                        refJson.getFrameIds(),
                        refJson.getDefaultFrameId(),
                        refJson.getIconUrl()
                ));
            }
            return result;
        } catch (Exception ex) {
            throw new LayoutException("Error parsing layout catalog:" + ex);
        }
        */
    }

    protected List<LayoutReference> fromClassLoaderResources() {
        Enumeration<URL> resources;
        try {
            resources = getClass().getClassLoader().getResources(LAYOUTS_CATALOG_PATH);
        } catch (Exception e) {
            throw new LayoutException("Error getting layout catalog resources: " + e);
        }
        List<LayoutReference> result = new ArrayList<>();
        while (resources.hasMoreElements()) {
            try (InputStream is = resources.nextElement().openStream()) {
                List<LayoutReference> refs = fromInputStream(is);
                result.addAll(refs);
            } catch (LayoutException e1) {
                throw e1;
            } catch (Exception e2) {
                throw new LayoutException("Error loading layout catalog: " + e2);
            }
        }
        return result;
    }

    @Inject
    public LayoutKitImpl(Injector injector) {
        this.injector = injector;
    }

    @Override
    public LayoutRender getLayoutRender(Class<? extends LayoutRender> renderClass) {
        return injector.get(renderClass);
    }

    @Override
    public List<LayoutReference> lookupLayoutReferences() {
        return fromClassLoaderResources();
    }

    @Override
    public List<WidgetReference> lookupWidgetReferences() {
        throw new UnsupportedOperationException("lookupWidgetReferences->Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
