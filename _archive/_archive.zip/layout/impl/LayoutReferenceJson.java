/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout.impl;

/**
 *
 * @author Vladlen Larionov
 */
public class LayoutReferenceJson {

    /**
     * Layout render class name
     */
    protected String render;

    /**
     * Layout id is used by the render to build layout html
     */
    protected String layoutId;

    /**
     * List of layout's frame ids
     */
    protected String[] frameIds;

    /**
     *
     */
    protected String defaultFrameId;

    protected String iconUrl;

    public LayoutReferenceJson() {
    }

    public String getRender() {
        return render;
    }

    public void setRender(String renderClassName) {
        this.render = renderClassName;
    }

    public String getLayoutId() {
        return layoutId;
    }

    public void setLayoutId(String layoutId) {
        this.layoutId = layoutId;
    }

    public String[] getFrameIds() {
        return frameIds;
    }

    public void setFrameIds(String[] frameIds) {
        this.frameIds = frameIds;
    }

    public String getDefaultFrameId() {
        return defaultFrameId;
    }

    public void setDefaultFrameId(String defaultFrameId) {
        this.defaultFrameId = defaultFrameId;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

}
