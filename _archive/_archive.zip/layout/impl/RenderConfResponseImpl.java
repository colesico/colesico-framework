/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout.impl;

import colesico.framework.layout.RenderConfResponse;
import colesico.framework.widget.CompositePage;

/**
 *
 * @author Vladlen Larionov
 */
public class RenderConfResponseImpl implements RenderConfResponse {

    protected final String fragmentId;
    protected final CompositePage compositePage;
    protected final LWPageFragment pageFragment;

    public RenderConfResponseImpl(CompositePage compositePage, String fragmentId) {
        this.fragmentId = fragmentId;
        this.compositePage = compositePage;
        this.pageFragment = new LWPageFragment();
        compositePage.putFragment(fragmentId, pageFragment);
    }

    @Override
    public void setConfigurable(boolean value) {
        pageFragment.setConfigurable(value);
    }

    @Override
    public void addResourceReference(String resourceType, String resourceId, String reference, String[] dependencies) {
        compositePage.getResourceReference().add(resourceType, resourceId, reference, dependencies);
    }

    @Override
    public void setContent(String widgetContent) {
        pageFragment.setContent(widgetContent);
    }

}
