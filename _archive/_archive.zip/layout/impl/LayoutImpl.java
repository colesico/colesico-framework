/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout.impl;

import colesico.framework.injector.Injector;
import colesico.framework.layout.*;
import colesico.framework.layout.exception.LayoutException;
import colesico.framework.modlet.ModletKit;
import colesico.framework.widget.CompositePage;
import colesico.framework.widget.RenderResponse;
import colesico.framework.widget.WidgetModlet;
import colesico.framework.widget.impl.PageFragmentImpl;
import colesico.framework.widget.impl.RenderResponseImpl;
import org.apache.commons.lang3.ArrayUtils;

import javax.inject.Inject;
import javax.inject.Provider;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Vladlen Larionov
 */
public class LayoutImpl implements Layout {

    protected final Injector injector;
    protected final ModletKit modletKit;
    protected final LayoutKit layoutKit;
    protected final Provider<CompositePage> compositePageProv;

    protected LayoutMode mode = LayoutMode.VIEW;

    protected Class<? extends LayoutRender> renderClass;
    protected String layoutId;

    protected Map<String, List<WidgetDescriptor>> soltsMap = new HashMap<>();

    @Inject
    public LayoutImpl(Injector injector, ModletKit modletKit, LayoutKit layoutKit, Provider<CompositePage> compositePageProv) {
        this.injector = injector;
        this.layoutKit = layoutKit;
        this.modletKit = modletKit;
        this.compositePageProv = compositePageProv;
    }

    @Override
    public void setMode(LayoutMode mode) {
        this.mode = mode;
    }

    @Override
    public void render() {
        CompositePage compositePage = compositePageProv.get();
        compositePage.seclude();
        if (mode.equals(LayoutMode.VIEW)) {
            renderWidgets();
        } else {
            renderWidgetsConf();
        }
        LayoutRender render = layoutKit.getLayoutRender(renderClass);
        String layoutContent = render.render(layoutId, mode, soltsMap);
        compositePage.restore();
        compositePage.putFragment(LAYOUT_FRAGMENT_ID, new PageFragmentImpl(layoutContent));
    }

    @Override
    public void createWidget(WidgetLocation location, WidgetReference widgetRef) {
        Class<? extends LayoutWidget> widgetModletClass;
        widgetModletClass = loadWidgetModletClass(widgetRef.getWidgetModlet());
        LayoutWidget widgetModlet = injector.get(widgetModletClass);
        String widgetId = widgetModlet.createWidget();
        WidgetDescriptor widgetDescr = new WidgetDescriptor(widgetId, widgetModletClass);
        List<WidgetDescriptor> frameWidgets = soltsMap.get(location.getFrameId());
        if (frameWidgets == null) {
            frameWidgets = new ArrayList<>();
        }
        frameWidgets.add(location.getIndex(), widgetDescr);
    }

    @Override
    public void configureWidget(WidgetLocation location, Class<? extends LayoutObserver> observerModletClass) {
        WidgetDescriptor wr = soltsMap.get(location.getFrameId()).get(location.getIndex());
        LayoutWidget widgetModlet = injector.get(wr.getWidgetModletClass());
        widgetModlet.configureWidget(wr.getWidgetId(), observerModletClass);
    }

    @Override
    public void relocateWidget(WidgetLocation srcLocation, WidgetLocation dstLocation) {
        WidgetDescriptor wr = soltsMap.get(srcLocation.getFrameId()).remove(srcLocation.getIndex().intValue());
        soltsMap.get(dstLocation.getFrameId()).add(dstLocation.getIndex(), wr);
    }

    @Override
    public WidgetDescriptor removeWidget(WidgetLocation location) {
        WidgetDescriptor wr = soltsMap.get(location.getFrameId()).remove(location.getIndex().intValue());
        LayoutWidget widgetModlet = injector.get(wr.getWidgetModletClass());
        ((LayoutWidget) widgetModlet).removeWidget(wr.getWidgetId());
        return wr;
    }

    @Override
    public void alter(LayoutReference layoutRef) {
        this.renderClass = loadRenderClass(layoutRef.getRender());

        this.layoutId = layoutRef.getLayoutId();

        Map<String, List<WidgetDescriptor>> soltsMapBackup = new HashMap<>();
        for (Map.Entry<String, List<WidgetDescriptor>> frameEntry : soltsMap.entrySet()) {
            List<WidgetDescriptor> frameWidgets = new ArrayList<>(frameEntry.getValue());
            soltsMapBackup.put(frameEntry.getKey(), frameWidgets);
        }

        this.soltsMap = initFramesMap(layoutRef.getFrameIds());
        for (Map.Entry<String, List<WidgetDescriptor>> frameEntry : soltsMapBackup.entrySet()) {
            String frameId = frameEntry.getKey();
            if (!ArrayUtils.contains(layoutRef.getFrameIds(),frameId)){
                frameId = layoutRef.getDefaultFrameId();
            }
            List<WidgetDescriptor> frameWidgets = this.soltsMap.get(frameId);
            frameWidgets.addAll(frameEntry.getValue());
        }
    }

    @Override
    public void importImage(LayoutImage layoutImg) {

        this.renderClass = loadRenderClass(layoutImg.getRender());

        this.layoutId = layoutImg.getLayoutId();

        this.soltsMap = new HashMap<>();

        for (Map.Entry<String, List<WidgetImage>> frameEntry : layoutImg.getSoltsMap().entrySet()) {
            List<WidgetDescriptor> frameWidgets = new ArrayList<>();
            this.soltsMap.put(frameEntry.getKey(), frameWidgets);
            for (WidgetImage widgIm : frameEntry.getValue()) {
                Class<? extends LayoutWidget> widgModletClass = loadWidgetModletClass(widgIm.getWidgetModlet());
                WidgetDescriptor widgDescr = new WidgetDescriptor(widgIm.getWidgetId(), widgModletClass);
                frameWidgets.add(widgDescr);
            }
        }

    }

    @Override
    public LayoutImage exportImage() {
        Map<String, List<WidgetImage>> slMap = new HashMap<>();

        for (Map.Entry<String, List<WidgetDescriptor>> e : this.soltsMap.entrySet()) {
            List<WidgetImage> frameWidgs = new ArrayList<>();
            for (WidgetDescriptor widgDescr : e.getValue()) {
                WidgetImage wi = new WidgetImage(widgDescr.getWidgetId(), widgDescr.getWidgetModletClass().getName());
                frameWidgs.add(wi);
            }
            slMap.put(e.getKey(), frameWidgs);
        }
        LayoutImage layoutImg = new LayoutImage(this.renderClass.getName(), this.layoutId, slMap);
        return layoutImg;
    }

    @Override
    public LayoutMode getMode() {
        return mode;
    }

    @Override
    public Map<String, List<WidgetDescriptor>> getSoltsMap() {
        return soltsMap;
    }

    @Override
    public Class<? extends LayoutRender> getRenderClass() {
        return renderClass;
    }

    @Override
    public String getLayoutId() {
        return layoutId;
    }

    protected Class<? extends LayoutRender> loadRenderClass(String renderClassName) throws LayoutException {
        try {
            Class<? extends LayoutRender> rendrCls = (Class<? extends LayoutRender>) Class.forName(renderClassName);
            return rendrCls;
        } catch (Exception ex) {
            throw new LayoutException("Error loading layout render class (" + renderClassName + "): " + ex);
        }
    }

    protected Class<? extends LayoutWidget> loadWidgetModletClass(String widgetModletClassName) {
        return (Class<? extends LayoutWidget>) modletKit.getModletClass(widgetModletClassName);
    }

    protected Map<String, List<WidgetDescriptor>> initFramesMap(String[] frameIds) {
        Map<String, List<WidgetDescriptor>> sm = new HashMap<>();
        for (String frameId : frameIds) {
            List<WidgetDescriptor> frameWidgets = new ArrayList<>();
            sm.put(frameId, frameWidgets);
        }
        return sm;
    }

    protected void renderWidgets() {
        for (Map.Entry<String, List<WidgetDescriptor>> frameEntry : soltsMap.entrySet()) {
            int ind = 0;
            for (WidgetDescriptor widgetDescr : frameEntry.getValue()) {
                String contentId = frameEntry.getKey() + ind;
                WidgetModlet widgetModlet = injector.get(widgetDescr.getWidgetModletClass());
                RenderResponse response = new RenderResponseImpl(compositePageProv.get(), contentId);
                widgetModlet.renderWidget(widgetDescr.getWidgetId(), response);
                ind++;
            }
        }
    }

    protected void renderWidgetsConf() {
        for (Map.Entry<String, List<WidgetDescriptor>> frameEntry : soltsMap.entrySet()) {
            int ind = 0;
            for (WidgetDescriptor widgetDescr : frameEntry.getValue()) {
                String contentId = frameEntry.getKey() + ind;
                WidgetModlet widgetModlet = injector.get(widgetDescr.getWidgetModletClass());
                RenderConfResponse response = new RenderConfResponseImpl(compositePageProv.get(), contentId);
                widgetModlet.renderWidget(widgetDescr.getWidgetId(), response);
                ind++;
            }
        }
    }

}
