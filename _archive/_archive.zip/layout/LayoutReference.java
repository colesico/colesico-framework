/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout;

/**
 *
 * @author Vladlen Larionov
 */
public class LayoutReference {

    /**
     * Layout render class name
     */
    protected final String render;

    /**
     * Layout id is used by the render to build layout html
     */
    protected final String layoutId;

    /**
     * List of layout's frame ids
     */
    protected final String[] frameIds;

    /**
     *
     */
    protected final String defaultFrameId;

    protected final String iconUrl;

    public LayoutReference(String renderClass, String layoutId, String[] frameIds, String defaultFrameId, String iconUrl) {
        this.render = renderClass;
        this.layoutId = layoutId;
        this.frameIds = frameIds;
        this.defaultFrameId = defaultFrameId;
        this.iconUrl = iconUrl;
    }

    public String getRender() {
        return render;
    }

    public String getLayoutId() {
        return layoutId;
    }

    public String[] getFrameIds() {
        return frameIds;
    }

    public String getDefaultFrameId() {
        return defaultFrameId;
    }

    public String getIconUrl() {
        return iconUrl;
    }

}
