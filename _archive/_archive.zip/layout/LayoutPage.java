/*
 * Copyright © 2014-2016 Vladlen Larionov. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package colesico.framework.layout;

import colesico.framework.injector.Injector;
import colesico.framework.layout.exception.LayoutException;
import colesico.framework.modlet.ModletKit;

/**
 *
 * @author Vladlen Larionov
 */
abstract public class LayoutPage implements LayoutObserver {

    public static final String PARAM_FRAME_ID = "frameId";
    public static final String PARAM_WIDGET_IND = "widgetInd";
    public static final String PARAM_DST_WIDGET_IND = "dstWidgetInd";
    public static final String PARAM_DST_FRAME_ID = "dstFrameId";
    public static final String PARAM_SRC_WIDGET_IND = "srcWidgetInd";
    public static final String PARAM_SRC_FRAME_ID = "srcFrameId";
    public static final String OBSERVER_ATTR_NAME = "layoutObserver";

    protected final Injector injector;
    protected final ModletKit modletKit;
    protected final Layout layout;

    public LayoutPage(Injector injector, ModletKit modletKit, Layout layout) {
        this.injector = injector;
        this.modletKit = modletKit;
        this.layout = layout;
    }

    abstract protected void onLayoutChanged();

    abstract protected Class<? extends LayoutPickerPage> getLayoutPicker();

    abstract protected Class<? extends WidgetPickerPage> getWidgetPicker();

    abstract public void selfRedirect();

    public Layout getLayout() {
        return layout;
    }

    protected WidgetLocation getWidgetLocation(String frameId, Integer widgetIndex) {
        if (frameId==null){
            throw new LayoutException("Frame id param (frameId) required");
        }
        if (widgetIndex==null){
            throw new LayoutException("Widget index param (widgetIndex) required");
        }
        return new WidgetLocation(frameId, widgetIndex);
    }


    public void removeWidget(String frameId, Integer widgetIndex) {
        WidgetLocation location = getWidgetLocation(frameId,widgetIndex);
        if (location != null) {
            layout.removeWidget(location);
            onLayoutChanged();
        }
    }

    public void configureWidget(String frameId, Integer widgetIndex) {
        WidgetLocation location = getWidgetLocation(frameId,widgetIndex);
        if (location != null) {
            layout.configureWidget(location, this.getClass());
            onLayoutChanged();
        }
    }

    public void relocateWidget(String srcFrameId, Integer srcWidgetIndex,String dstFrameId, Integer dstWidgetIndex) {
        WidgetLocation srcLocation = getWidgetLocation(srcFrameId,srcWidgetIndex);
        WidgetLocation dstLocation = getWidgetLocation(dstFrameId,dstWidgetIndex);
        if ((srcLocation != null) && (dstLocation != null)) {
            layout.relocateWidget(srcLocation, dstLocation);
            onLayoutChanged();
        }
    }

    public void pickLayout() {
        Class observerModletClass = modletKit.getModletClass(this);
        LayoutPickerPage pickerModlet = injector.get(getLayoutPicker());
        pickerModlet.goPickLayout(observerModletClass);
    }

    public void pickWidget() {
        Class observerModletClass = modletKit.getModletClass(this);
        WidgetPickerPage pickerModlet = injector.get(getWidgetPicker());
        pickerModlet.goPickWidget(observerModletClass);
    }

    public void configMode() {
        layout.setMode(LayoutMode.CONFIG);
    }

    public void viewMode() {
        layout.setMode(LayoutMode.VIEW);
    }

    @Override
    public void onLayoutPicked(LayoutReference layoutRef) {
        layout.alter(layoutRef);
        onLayoutChanged();
        selfRedirect();
    }

    @Override
    public void onWidgetPicked(WidgetReference widgetRef) {
        onLayoutChanged();
        selfRedirect();
        throw new UnsupportedOperationException("onWidgetPicked->Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
